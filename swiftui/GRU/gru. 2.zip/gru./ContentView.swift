//
//  ContentView.swift
//  gru.
//
//  Created by Maria Morozova on 04.07.2026.
//


import SwiftUI

struct ContentView: View {

    var body: some View {

        MainView()
    }
}

#Preview {

    ContentView()
}