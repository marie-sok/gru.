
//
//  GRUColors.swift
//  gru.
//
//  Created by Maria Morozova on 03.07.2026.
//

import SwiftUI

enum GRUColors {

    // MARK: - Main Accent

    static let accent = Color(
        uiColor: UIColor { trait in

            if trait.userInterfaceStyle == .dark {

                return UIColor(
                    red: 0.84,
                    green: 0.82,
                    blue: 0.94,
                    alpha: 1
                )

            } else {

                return UIColor(
                    red: 0.34,
                    green: 0.31,
                    blue: 0.46,
                    alpha: 1
                )
            }
        }
    )

    // MARK: - Background

    static let background = Color(
        uiColor: UIColor { trait in

            if trait.userInterfaceStyle == .dark {

                return UIColor(
                    red: 0.045,
                    green: 0.045,
                    blue: 0.055,
                    alpha: 1
                )

            } else {

                return UIColor(
                    red: 0.975,
                    green: 0.972,
                    blue: 0.978,
                    alpha: 1
                )
            }
        }
    )

    // MARK: - Card

    static let card = Color(
        uiColor: UIColor { trait in

            if trait.userInterfaceStyle == .dark {

                return UIColor(
                    red: 0.10,
                    green: 0.10,
                    blue: 0.12,
                    alpha: 1
                )

            } else {

                return UIColor(
                    red: 1,
                    green: 1,
                    blue: 1,
                    alpha: 1
                )
            }
        }
    )

    // MARK: - Input

    static let input = Color(
        uiColor: UIColor { trait in

            if trait.userInterfaceStyle == .dark {

                return UIColor(
                    red: 0.12,
                    green: 0.12,
                    blue: 0.14,
                    alpha: 1
                )

            } else {

                return UIColor(
                    red: 0.95,
                    green: 0.95,
                    blue: 0.96,
                    alpha: 1
                )
            }
        }
    )

    // MARK: - Text

    static let text = Color.primary

    static let secondary = Color.secondary

    // MARK: - Separator

    static let separator = Color(
        uiColor: UIColor { trait in

            if trait.userInterfaceStyle == .dark {

                return UIColor.white
                    .withAlphaComponent(0.06)

            } else {

                return UIColor.black
                    .withAlphaComponent(0.06)
            }
        }
    )

    // MARK: - Incoming Message

    static let incomingBubble = Color(
        uiColor: UIColor { trait in

            if trait.userInterfaceStyle == .dark {

                return UIColor(
                    red: 0.12,
                    green: 0.12,
                    blue: 0.14,
                    alpha: 1
                )

            } else {

                return UIColor(
                    red: 0.94,
                    green: 0.94,
                    blue: 0.95,
                    alpha: 1
                )
            }
        }
    )

    // MARK: - Outgoing Message

    static let outgoingBubble = Color(
        uiColor: UIColor { trait in

            if trait.userInterfaceStyle == .dark {

                return UIColor(
                    red: 0.26,
                    green: 0.24,
                    blue: 0.34,
                    alpha: 1
                )

            } else {

                return UIColor(
                    red: 0.87,
                    green: 0.85,
                    blue: 0.93,
                    alpha: 1
                )
            }
        }
    )

    // MARK: - Pastel Palettes

    enum Pastel {

        // Milk

        static let milkBackground = Color(
            red: 0.98,
            green: 0.96,
            blue: 0.92
        )

        static let milkCard = Color(
            red: 1.00,
            green: 0.99,
            blue: 0.97
        )

        static let milkAccent = Color(
            red: 0.53,
            green: 0.45,
            blue: 0.39
        )

        // Blush

        static let blushBackground = Color(
            red: 0.98,
            green: 0.91,
            blue: 0.92
        )

        static let blushCard = Color(
            red: 1.00,
            green: 0.96,
            blue: 0.97
        )

        static let blushAccent = Color(
            red: 0.64,
            green: 0.39,
            blue: 0.45
        )

        // Lavender

        static let lavenderBackground = Color(
            red: 0.94,
            green: 0.92,
            blue: 0.98
        )

        static let lavenderCard = Color(
            red: 0.98,
            green: 0.97,
            blue: 1.00
        )

        static let lavenderAccent = Color(
            red: 0.47,
            green: 0.40,
            blue: 0.64
        )

        // Sage

        static let sageBackground = Color(
            red: 0.91,
            green: 0.95,
            blue: 0.90
        )

        static let sageCard = Color(
            red: 0.96,
            green: 0.98,
            blue: 0.95
        )

        static let sageAccent = Color(
            red: 0.36,
            green: 0.49,
            blue: 0.37
        )

        // Sky

        static let skyBackground = Color(
            red: 0.91,
            green: 0.95,
            blue: 0.98
        )

        static let skyCard = Color(
            red: 0.97,
            green: 0.99,
            blue: 1.00
        )

        static let skyAccent = Color(
            red: 0.34,
            green: 0.49,
            blue: 0.62
        )

        // Peach

        static let peachBackground = Color(
            red: 0.99,
            green: 0.93,
            blue: 0.88
        )

        static let peachCard = Color(
            red: 1.00,
            green: 0.97,
            blue: 0.94
        )

        static let peachAccent = Color(
            red: 0.67,
            green: 0.42,
            blue: 0.31
        )
    }
}
