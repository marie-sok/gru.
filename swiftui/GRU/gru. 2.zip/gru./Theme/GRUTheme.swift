//
//  GRUTheme.swift
//  gru.
//
//  Created by Maria Morozova on 03.07.2026.
//


import SwiftUI

enum GRUTheme {

    static let radius: CGFloat = 22

    static let tabBarHeight: CGFloat = 72

    static let spacing: CGFloat = 18

    static let animation: Animation = .spring(
        response: 0.38,
        dampingFraction: 0.82
    )
}