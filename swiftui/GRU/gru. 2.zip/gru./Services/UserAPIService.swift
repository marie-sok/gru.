//
//  UserAPIService.swift
//  gru
//
//  Created by Maria Morozova on 24.08.2026.
//


import Foundation

final class UserAPIService {

    static let shared =
        UserAPIService()

    private init() {}

    // MARK: - Search Users

    func searchUsers(
        nickname: String,
        token: String
    ) async throws -> [UserSearchDTO] {

        var components =
            URLComponents()

        components.queryItems = [
            URLQueryItem(
                name: "nickname",
                value: nickname
            )
        ]

        let query =
            components
                .percentEncodedQuery
            ?? ""

        let data =
            try await APIClient.shared.request(
                path:
                    "/users/search?\(query)",
                method: "GET",
                token: token
            )

        return try JSONCoding.decoder.decode(
            [UserSearchDTO].self,
            from: data
        )
    }
}