import Foundation

enum APIError: LocalizedError {

    case invalidURL
    case invalidResponse
    case unauthorized
    case forbidden
    case notFound
    case serverError(Int)
    case httpError(Int, String)
    case network(Error)

    var errorDescription: String? {

        switch self {

        case .invalidURL:
            return "Некорректный адрес сервера"

        case .invalidResponse:
            return "Некорректный ответ сервера"

        case .unauthorized:
            return "Сессия истекла. Войдите снова"

        case .forbidden:
            return "Доступ запрещён"

        case .notFound:
            return "Запрашиваемые данные не найдены"

        case .serverError(let code):
            return "Ошибка сервера: \(code)"

        case .httpError(let code, let message):

            if message.isEmpty {
                return "HTTP ошибка: \(code)"
            }

            return message

        case .network(let error):
            return "Ошибка сети: \(error.localizedDescription)"
        }
    }
}

final class APIClient {

    static let shared =
        APIClient()

    private init() {}

    private let baseURL =
        "http://192.168.31.157:8081"

    // MARK: - JSON / Standard Request

    func request(
        path: String,
        method: String = "GET",
        token: String? = nil,
        body: Data? = nil
    ) async throws -> Data {

        let url =
            try makeURL(
                path: path
            )

        var request =
            URLRequest(
                url: url
            )

        request.httpMethod =
            method

        request.timeoutInterval =
            30

        request.setValue(
            "application/json",
            forHTTPHeaderField:
                "Accept"
        )

        if body != nil {

            request.setValue(
                "application/json",
                forHTTPHeaderField:
                    "Content-Type"
            )
        }

        applyAuthorization(
            token,
            to: &request
        )

        request.httpBody =
            body

        #if DEBUG

        print(
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        )

        print(
            "🌐 \(method) \(url.absoluteString)"
        )

        if token != nil {

            print(
                "🔐 Authorization: Bearer ***"
            )
        }

        if let body,
           let string =
            String(
                data: body,
                encoding: .utf8
            ) {

            print(
                "📤 BODY:",
                string
            )
        }

        #endif

        return try await
            perform(
                request,
                printResponseBody:
                    true
            )
    }

    // MARK: - Multipart Upload

    func uploadMultipart(
        path: String,
        token: String,
        fields: [String: String],
        fileFieldName: String,
        fileName: String,
        mimeType: String,
        fileData: Data
    ) async throws -> Data {

        let url =
            try makeURL(
                path: path
            )

        let boundary =
            "Boundary-\(UUID().uuidString)"

        var body =
            Data()

        for key in fields.keys.sorted() {

            guard let value =
                fields[key]
            else {
                continue
            }

            body.appendMultipartString(
                "--\(boundary)\r\n"
            )

            body.appendMultipartString(
                "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n"
            )

            body.appendMultipartString(
                "\(value)\r\n"
            )
        }

        body.appendMultipartString(
            "--\(boundary)\r\n"
        )

        body.appendMultipartString(
            "Content-Disposition: form-data; name=\"\(fileFieldName)\"; filename=\"\(fileName)\"\r\n"
        )

        body.appendMultipartString(
            "Content-Type: \(mimeType)\r\n\r\n"
        )

        body.append(
            fileData
        )

        body.appendMultipartString(
            "\r\n--\(boundary)--\r\n"
        )

        var request =
            URLRequest(
                url: url
            )

        request.httpMethod =
            "POST"

        request.timeoutInterval =
            60

        request.setValue(
            "application/json",
            forHTTPHeaderField:
                "Accept"
        )

        request.setValue(
            "multipart/form-data; boundary=\(boundary)",
            forHTTPHeaderField:
                "Content-Type"
        )

        applyAuthorization(
            token,
            to: &request
        )

        request.httpBody =
            body

        #if DEBUG

        print(
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        )

        print(
            "🌐 POST \(url.absoluteString)"
        )

        print(
            "🔐 Authorization: Bearer ***"
        )

        print(
            "📤 MULTIPART FIELDS:",
            fields
        )

        print(
            "📎 FILE:",
            fileName,
            "(\(fileData.count) bytes)"
        )

        #endif

        return try await
            perform(
                request,
                printResponseBody:
                    true
            )
    }

    // MARK: - Authenticated Download

    func download(
        path: String,
        token: String
    ) async throws -> Data {

        let url =
            try makeURL(
                path: path
            )

        var request =
            URLRequest(
                url: url
            )

        request.httpMethod =
            "GET"

        request.timeoutInterval =
            60

        request.setValue(
            "*/*",
            forHTTPHeaderField:
                "Accept"
        )

        applyAuthorization(
            token,
            to: &request
        )

        #if DEBUG

        print(
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        )

        print(
            "🖼 GET MEDIA \(url.absoluteString)"
        )

        print(
            "🔐 Authorization: Bearer ***"
        )

        #endif

        return try await
            perform(
                request,
                printResponseBody:
                    false
            )
    }

    // MARK: - Perform

    private func perform(
        _ request: URLRequest,
        printResponseBody: Bool
    ) async throws -> Data {

        do {

            let (
                data,
                response
            ) =
                try await
                    URLSession.shared
                    .data(
                        for: request
                    )

            guard let httpResponse =
                response
                as? HTTPURLResponse
            else {

                throw APIError.invalidResponse
            }

            #if DEBUG

            print(
                "📥 STATUS:",
                httpResponse.statusCode
            )

            if printResponseBody,
               let responseString =
                String(
                    data: data,
                    encoding: .utf8
                ),
               !responseString.isEmpty {

                print(
                    "📥 RESPONSE:",
                    responseString
                )
            }

            print(
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            )

            #endif

            if 200...299 ~=
                httpResponse.statusCode {

                return data
            }

            let serverMessage =
                extractServerMessage(
                    from: data
                )

            if shouldInvalidateSession(
                statusCode:
                    httpResponse.statusCode,
                serverMessage:
                    serverMessage,
                request:
                    request
            ) {

                await invalidateCurrentSession(
                    statusCode:
                        httpResponse.statusCode
                )
            }

            switch httpResponse.statusCode {

            case 401:
                throw APIError.unauthorized

            case 403:

                if TokenStorage.shared.token == nil {
                    throw APIError.unauthorized
                }

                throw APIError.forbidden

            case 404:
                throw APIError.notFound

            case 500...599:

                if !serverMessage.isEmpty {

                    throw APIError.httpError(
                        httpResponse.statusCode,
                        serverMessage
                    )
                }

                throw APIError.serverError(
                    httpResponse.statusCode
                )

            default:

                throw APIError.httpError(
                    httpResponse.statusCode,
                    serverMessage
                )
            }

        } catch let error as APIError {

            throw error

        } catch {

            throw APIError.network(
                error
            )
        }
    }

    // MARK: - Session Invalidation

    private func shouldInvalidateSession(
        statusCode: Int,
        serverMessage: String,
        request: URLRequest
    ) -> Bool {

        guard
            request.value(
                forHTTPHeaderField:
                    "Authorization"
            ) != nil
        else {

            return false
        }

        if statusCode == 401 {
            return true
        }

        guard statusCode == 403 else {
            return false
        }

        let normalizedMessage =
            serverMessage
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )
                .lowercased()

        let path =
            request.url?.path ?? ""

        /*
         Spring Security currently returns
         403 + "Access Denied" for an invalid
         or expired JWT session as well.

         A domain-level 403 (for example,
         not being a participant of a chat)
         must NOT log the user out.
         */
        return
            path == "/chats" ||
            normalizedMessage == "access denied" ||
            normalizedMessage == "unauthorized" ||
            normalizedMessage.contains(
                "jwt"
            ) ||
            normalizedMessage.contains(
                "token expired"
            ) ||
            normalizedMessage.contains(
                "token is expired"
            )
    }

    private func invalidateCurrentSession(
        statusCode: Int
    ) async {

        await MainActor.run {

            guard
                TokenStorage.shared.token != nil ||
                TokenStorage.shared.userID != nil
            else {

                return
            }

            print("")
            print(
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            )
            print(
                "🔐 SESSION INVALIDATED"
            )
            print(
                "📥 HTTP status:",
                statusCode
            )
            print(
                "➡️ Returning to LoginView"
            )
            print(
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            )

            WebSocketService.shared
                .resetSession()

            TokenStorage.shared
                .clear()

            ChatService.shared
                .clearAuthenticatedUser()

            NotificationCenter.default
                .post(
                    name:
                        .gruSessionInvalidated,
                    object:
                        nil
                )
        }
    }

    // MARK: - URL

    private func makeURL(
        path: String
    ) throws -> URL {

        if let absoluteURL =
            URL(
                string: path
            ),
           absoluteURL.scheme != nil {

            return absoluteURL
        }

        let normalizedPath =
            path.hasPrefix("/")
            ? path
            : "/" + path

        guard let url =
            URL(
                string:
                    baseURL +
                    normalizedPath
            )
        else {

            throw APIError.invalidURL
        }

        return url
    }

    // MARK: - Auth

    private func applyAuthorization(
        _ token: String?,
        to request: inout URLRequest
    ) {

        guard let token,
              !token.isEmpty
        else {

            return
        }

        request.setValue(
            "Bearer \(token)",
            forHTTPHeaderField:
                "Authorization"
        )
    }

    // MARK: - Server Error Message

    private func extractServerMessage(
        from data: Data
    ) -> String {

        guard !data.isEmpty else {
            return ""
        }

        if let json =
            try? JSONSerialization
            .jsonObject(
                with: data
            )
            as? [String: Any] {

            if let message =
                json["message"]
                as? String,
               !message.isEmpty {

                return message
            }

            if let error =
                json["error"]
                as? String,
               !error.isEmpty {

                return error
            }
        }

        if let rawText =
            String(
                data: data,
                encoding: .utf8
            ) {

            let text =
                rawText
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

            if !text.isEmpty {
                return text
            }
        }

        return ""
    }
}

private extension Data {

    mutating func appendMultipartString(
        _ string: String
    ) {

        guard let data =
            string.data(
                using: .utf8
            )
        else {

            return
        }

        append(
            data
        )
    }
}
