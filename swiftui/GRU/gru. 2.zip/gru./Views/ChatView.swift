import PhotosUI
import SwiftUI
import UIKit
import UniformTypeIdentifiers

@MainActor
struct ChatView: View {
    @Environment(\.dismiss) private var dismiss

    @Bindable private var vm: ChatViewModel

    @State private var showPhotoPicker = false
    @State private var selectedPhoto: PhotosPickerItem?

    @State private var showVideoSourceDialog = false
    @State private var showVideoLibraryPicker = false
    @State private var selectedVideo: PhotosPickerItem?
    @State private var showVideoCamera = false

    @State private var showVideoNoteRecorder = false
    @State private var showVoiceRecorder = false
    @State private var showDocumentPicker = false
    @State private var showContactPicker = false
    @State private var showBackgroundPicker = false
    @State private var searching = false

    @AppStorage private var chatBackgroundRaw: String

    init(chat: Chat) {
        _vm = Bindable(wrappedValue: ChatViewModel(chat: chat))

        let key = chat.serverID ?? chat.id.uuidString
        _chatBackgroundRaw = AppStorage(
            wrappedValue: ChatBackgroundStyle.obsidian.rawValue,
            "gru.chat.background.\(key)"
        )
    }

    private var backgroundStyle: ChatBackgroundStyle {
        ChatBackgroundStyle(rawValue: chatBackgroundRaw) ?? .obsidian
    }

    var body: some View {
        ZStack {
            ChatBackgroundView(style: backgroundStyle)

            VStack(spacing: 0) {
                header

                if searching {
                    SearchBar(
                        text: $vm.searchText,
                        resultsText: vm.searchCountText,
                        onSearch: { vm.performSearch() },
                        onNext: { vm.nextResult() },
                        onPrevious: { vm.previousResult() },
                        onClose: {
                            withAnimation {
                                searching = false
                                vm.clearSearch()
                            }
                        }
                    )
                }

                Divider().opacity(0.08)

                messages

                if let reply = vm.replyMessage {
                    ReplyBar(message: reply) {
                        vm.cancelReply()
                    }
                }

                ChatInputBar(
                    text: $vm.messageText,
                    sendTrigger: $vm.sendTrigger,
                    onSend: {
                        vm.sendMessage()
                    },
                    onAttachment: { action in
                        switch action {
                        case .photo:
                            showPhotoPicker = true

                        case .video:
                            showVideoSourceDialog = true

                        case .document:
                            showDocumentPicker = true

                        case .voice:
                            showVoiceRecorder = true

                        case .videoNote:
                            showVideoNoteRecorder = true

                        case .contact:
                            showContactPicker = true
                        }
                    },
                    onAudioRecorded: { recording in
                        Task {
                            await vm.sendAudio(
                                url: recording.url,
                                duration: recording.duration,
                                waveform: recording.waveform
                            )
                            try? FileManager.default.removeItem(at: recording.url)
                        }
                    }
                )
            }
        }
        .navigationBarBackButtonHidden(true)
        .task {
            await vm.loadMessages()
        }
        .onDisappear {
            vm.stopRealtime()
        }
        .confirmationDialog(
            "Видео",
            isPresented: $showVideoSourceDialog,
            titleVisibility: .visible
        ) {
            Button("Выбрать из медиатеки") {
                showVideoLibraryPicker = true
            }

            Button("Снять камерой") {
                showVideoCamera = true
            }
            .disabled(!UIImagePickerController.isSourceTypeAvailable(.camera))

            Button("Отмена", role: .cancel) {}
        } message: {
            Text("Отправь обычное видео из медиатеки или сними новое.")
        }
        .photosPicker(
            isPresented: $showPhotoPicker,
            selection: $selectedPhoto,
            matching: .images
        )
        .photosPicker(
            isPresented: $showVideoLibraryPicker,
            selection: $selectedVideo,
            matching: .videos
        )
        .onChange(of: selectedPhoto) { _, item in
            guard let item else { return }

            Task {
                if let data = try? await item.loadTransferable(type: Data.self),
                   let image = UIImage(data: data) {
                    vm.sendImage(image)
                }

                await MainActor.run {
                    selectedPhoto = nil
                }
            }
        }
        .onChange(of: selectedVideo) { _, item in
            guard let item else { return }

            Task {
                do {
                    guard let picked = try await item.loadTransferable(type: PickedVideo.self) else {
                        return
                    }

                    await vm.sendVideo(picked.url)
                    try? FileManager.default.removeItem(at: picked.url)
                } catch {
                    print("❌ Video library error:", error)
                }

                await MainActor.run {
                    selectedVideo = nil
                }
            }
        }
        .fullScreenCover(isPresented: $showVideoCamera) {
            VideoCameraPicker(
                onPicked: { url in
                    showVideoCamera = false
                    Task {
                        await vm.sendVideo(url)
                        try? FileManager.default.removeItem(at: url)
                    }
                },
                onCancel: {
                    showVideoCamera = false
                }
            )
            .ignoresSafeArea()
        }
        .fileImporter(
            isPresented: $showDocumentPicker,
            allowedContentTypes: [.item],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                Task {
                    await vm.sendDocument(url)
                }
            case .failure(let error):
                print("❌ Document picker error:", error)
            }
        }
        .sheet(isPresented: $showContactPicker) {
            ContactSharePickerView { contact in
                guard let phone = contact.primaryPhone else { return }
                vm.sendContactCard(
                    name: contact.displayName,
                    phone: phone
                )
            }
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showVoiceRecorder) {
            VoiceAudioRecorderView { recording in
                Task {
                    await vm.sendAudio(
                        url: recording.url,
                        duration: recording.duration,
                        waveform: recording.waveform
                    )
                    try? FileManager.default.removeItem(at: recording.url)
                }
            }
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
        .fullScreenCover(isPresented: $showVideoNoteRecorder) {
            VideoNoteRecorderView { url in
                Task {
                    await vm.sendVideoNote(url)
                    try? FileManager.default.removeItem(at: url)
                }
            }
        }
        .sheet(isPresented: $showBackgroundPicker) {
            ChatBackgroundPicker(selectedRawValue: $chatBackgroundRaw)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
    }
}

// MARK: - Header

private extension ChatView {
    var header: some View {
        HStack(spacing: 12) {
            GRUNeonIconButton(
                systemName: "chevron.left",
                accessibilityLabel: "Назад",
                size: 38,
                iconSize: 15
            ) {
                dismiss()
            }

            Circle()
                .fill(GRUColors.card.opacity(0.90))
                .frame(width: 40, height: 40)
                .overlay {
                    Image(systemName: "person.fill")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(GRUColors.accent)
                }
                .overlay {
                    Circle()
                        .stroke(GRUColors.accent.opacity(0.26), lineWidth: 1)
                }
                .shadow(color: GRUColors.accent.opacity(0.14), radius: 7)

            VStack(alignment: .leading, spacing: 2) {
                Text(chatName)
                    .font(.headline)

                Text(vm.isOtherUserTyping ? "печатает…" : chatStatus)
                    .font(.caption)
                    .foregroundStyle(vm.isOtherUserTyping ? GRUColors.accent : .secondary)
            }

            Spacer()

            GRUNeonIconButton(
                systemName: "paintpalette.fill",
                accessibilityLabel: "Фон чата",
                size: 38,
                iconSize: 15
            ) {
                showBackgroundPicker = true
            }

            GRUNeonIconButton(
                systemName: "magnifyingglass",
                accessibilityLabel: "Поиск",
                size: 38,
                iconSize: 15,
                isActive: searching
            ) {
                withAnimation {
                    searching.toggle()
                    if !searching {
                        vm.clearSearch()
                    }
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial)
    }

    var chatName: String {
        vm.chat.users.first {
            $0.id != ChatService.shared.currentUser.id
        }?.displayName ?? "Chat"
    }

    var chatStatus: String {
        guard let user = vm.chat.users.first(where: {
            $0.id != ChatService.shared.currentUser.id
        }) else {
            return ""
        }

        return user.isOnline ? "Online" : "Offline"
    }
}

// MARK: - Messages

private extension ChatView {
    var messages: some View {
        ScrollViewReader { proxy in
            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 14) {
                    ForEach(vm.chat.messages) { message in
                        MessageBubble(
                            message: message,
                            isCurrentUser: message.senderID == ChatService.shared.currentUser.id,
                            onReply: { message in
                                vm.startReply(to: message)
                            },
                            onDeleteLocal: { message in
                                vm.deleteLocal(message)
                            },
                            onDeleteForEveryone: { message in
                                vm.deleteForEveryone(message)
                            },
                            onSaveVideoNote: { message in
                                ProfileStorage.shared.saveVideoNote(message)
                                UINotificationFeedbackGenerator()
                                    .notificationOccurred(.success)
                            },
                            onReaction: { reaction, message in
                                if message.reaction == reaction {
                                    vm.removeReaction(from: message)
                                } else {
                                    vm.addReaction(reaction, to: message)
                                }
                            }
                        )
                        .id(message.id)
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 10)
            }
            .onAppear {
                scrollToLast(proxy: proxy, animated: false)
            }
            .onChange(of: vm.chat.messages.count) { _, _ in
                scrollToLast(proxy: proxy, animated: true)
            }
        }
    }

    func scrollToLast(proxy: ScrollViewProxy, animated: Bool) {
        guard let last = vm.chat.messages.last else { return }

        if animated {
            withAnimation(.easeOut(duration: 0.25)) {
                proxy.scrollTo(last.id, anchor: .bottom)
            }
        } else {
            proxy.scrollTo(last.id, anchor: .bottom)
        }
    }
}

#Preview {
    NavigationStack {
        ChatView(
            chat: Chat(
                users: [
                    ChatService.shared.currentUser,
                    User(username: "alex", displayName: "Alex", isOnline: true)
                ],
                messages: [
                    Message(senderID: UUID(), text: "Привет 👋"),
                    Message(
                        senderID: ChatService.shared.currentUser.id,
                        text: "GRU Messenger"
                    )
                ]
            )
        )
    }
}
