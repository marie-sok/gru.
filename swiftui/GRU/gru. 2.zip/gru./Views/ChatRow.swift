
import SwiftUI

@MainActor
struct ChatRow: View {

    let chat: Chat

    private var currentUser: User {
        ChatService.shared.currentUser
    }

    // MARK: - Other User

    private var otherUser: User? {

        // Сначала ищем по serverID.
        // Это основной и правильный способ.

        if let myServerID = currentUser.serverID {

            if let user = chat.users.first(
                where: {
                    $0.serverID != nil &&
                    $0.serverID != myServerID
                }
            ) {

                return user
            }
        }

        // Fallback для локальных чатов

        return chat.users.first(
            where: {
                $0.id != currentUser.id
            }
        )
    }

    // MARK: - Title

    private var chatTitle: String {

        // Групповой чат

        if chat.isGroup {

            if let title = chat.title,
               !title.trimmingCharacters(
                    in: .whitespacesAndNewlines
               ).isEmpty {

                return title
            }

            return "Группа"
        }

        // Личный чат

        if let otherUser {

            let name =
                otherUser.displayName
                    .trimmingCharacters(
                        in: .whitespacesAndNewlines
                    )

            if !name.isEmpty &&
                name.lowercased() != "you" {

                return name
            }

            let username =
                otherUser.username
                    .trimmingCharacters(
                        in: .whitespacesAndNewlines
                    )

            if !username.isEmpty &&
                username.lowercased() != "you" {

                return username
            }
        }

        /*
         Если backend вернул чат,
         в котором пока есть только
         текущий пользователь,
         не показываем "You".
         */

        return "User"
    }

    // MARK: - Body

    var body: some View {

        HStack(
            spacing: 14
        ) {

            avatar

            VStack(
                alignment: .leading,
                spacing: 5
            ) {

                Text(chatTitle)
                    .font(
                        .system(
                            size: 17,
                            weight: .semibold,
                            design: .rounded
                        )
                    )
                    .foregroundStyle(
                        .primary
                    )

                if !lastMessage.isEmpty {

                    Text(lastMessage)
                        .font(
                            .system(
                                size: 14,
                                weight: .regular,
                                design: .rounded
                            )
                        )
                        .foregroundStyle(
                            .secondary
                        )
                        .lineLimit(1)

                } else {

                    Text("Нет сообщений")
                        .font(
                            .system(
                                size: 14,
                                weight: .regular,
                                design: .rounded
                            )
                        )
                        .foregroundStyle(
                            .tertiary
                        )
                }
            }

            Spacer(
                minLength: 8
            )

            VStack(
                alignment: .trailing,
                spacing: 7
            ) {

                if !lastTime.isEmpty {

                    Text(lastTime)
                        .font(
                            .system(
                                size: 12,
                                weight: .regular,
                                design: .rounded
                            )
                        )
                        .foregroundStyle(
                            .secondary
                        )
                }

                if chat.unreadCount > 0 {

                    Text(
                        "\(chat.unreadCount)"
                    )
                    .font(
                        .system(
                            size: 11,
                            weight: .semibold,
                            design: .rounded
                        )
                    )
                    .foregroundStyle(
                        .white
                    )
                    .frame(
                        minWidth: 20,
                        minHeight: 20
                    )
                    .padding(
                        .horizontal,
                        chat.unreadCount > 9 ? 4 : 0
                    )
                    .background(
                        .primary
                    )
                    .clipShape(
                        Capsule()
                    )
                }
            }
        }
        .padding(
            .vertical,
            7
        )
    }

    // MARK: - Avatar

    @ViewBuilder
    private var avatar: some View {

        if let otherUser {

            AvatarView(
                user: otherUser,
                size: 56
            )

        } else {

            ZStack {

                Circle()
                    .fill(
                        Color.secondary
                            .opacity(0.12)
                    )

                Image(
                    systemName:
                        "person.fill"
                )
                .font(
                    .system(
                        size: 21,
                        weight: .light
                    )
                )
                .foregroundStyle(
                    .secondary
                )
            }
            .frame(
                width: 56,
                height: 56
            )
        }
    }

    // MARK: - Last Message

    private var lastMessage: String {

        guard let message =
                chat.messages.last
        else {

            return ""
        }

        let text =
            message.text
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if !text.isEmpty {

            return text
        }

        if let attachment =
            message.attachment {

            switch attachment.type {

            case .photo:
                return "Фото"

            case .video:
                return "Видео"

            case .videoNote:
                return "Видеосообщение"

            case .document:
                return "Документ"

            case .audio:
                return "Аудио"
            }
        }

        return ""
    }

    // MARK: - Time

    private var lastTime: String {

        guard let date =
                chat.messages.last?.sentAt
        else {

            return ""
        }

        let formatter =
            DateFormatter()

        if Calendar.current.isDateInToday(
            date
        ) {

            formatter.dateFormat =
                "HH:mm"

        } else {

            formatter.dateFormat =
                "dd.MM"
        }

        return formatter.string(
            from: date
        )
    }
}
