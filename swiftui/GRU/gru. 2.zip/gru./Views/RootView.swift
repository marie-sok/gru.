//
//  RootView.swift
//  gru
//
//  Created by Maria Morozova on 23.08.2026.
//


import SwiftUI
import Combine

@MainActor
struct RootView: View {

    // MARK: - State

    @State
    private var isAuthenticated = false

    @State
    private var isCheckingSession = true

    // MARK: - One-Time Reset


    private let sessionMigrationKey =
        "gru.sessionMigration.v1"

    // MARK: - Body

    var body: some View {

        Group {

            if isCheckingSession {

                loadingView

            } else if isAuthenticated {

                MainView()

            } else {

                LoginView(
                    onLogin: {

                        handleSuccessfulLogin()
                    }
                )
            }
        }
        .task {

            checkSession()
        }
        .onReceive(
            NotificationCenter.default
                .publisher(
                    for:
                        .gruSessionInvalidated
                )
        ) {
            _ in

            handleSessionInvalidated()
        }
    }
}

// MARK: - Session

private extension RootView {

    func checkSession() {

        performOneTimeSessionResetIfNeeded()

        let token =
            TokenStorage.shared.token

        let userID =
            TokenStorage.shared.userID

        if let token,
           !token.isEmpty,
           let userID,
           !userID.isEmpty {

            ChatService.shared.restoreSession()

            isAuthenticated = true

        } else {

            isAuthenticated = false
        }

        isCheckingSession = false
    }

    func performOneTimeSessionResetIfNeeded() {

        let defaults =
            UserDefaults.standard

        let alreadyMigrated =
            defaults.bool(
                forKey: sessionMigrationKey
            )

        guard !alreadyMigrated else {
            return
        }

        /*
         Удаляем старую сессию,
         где сохранялся только JWT.
         */

        TokenStorage.shared.clear()

        ChatService.shared
            .clearAuthenticatedUser()

        defaults.set(
            true,
            forKey: sessionMigrationKey
        )

        print(
            "🧹 Old GRU session cleared"
        )
    }

    func handleSessionInvalidated() {

        isCheckingSession =
            false

        withAnimation(
            .easeInOut(
                duration:
                    0.25
            )
        ) {

            isAuthenticated =
                false
        }

        print(
            "🔐 GRU session expired — LoginView"
        )
    }

    func handleSuccessfulLogin() {

        guard
            let token =
                TokenStorage.shared.token,
            !token.isEmpty,
            let userID =
                TokenStorage.shared.userID,
            !userID.isEmpty
        else {

            print(
                "❌ Login completed but session was not saved"
            )

            isAuthenticated = false

            return
        }

        ChatService.shared.restoreSession()

        withAnimation(
            .easeInOut(
                duration: 0.25
            )
        ) {

            isAuthenticated = true
        }

        print(
            "✅ GRU session authenticated"
        )
    }
}

// MARK: - Loading

private extension RootView {

    var loadingView: some View {

        ZStack {

            GRUColors.background
                .ignoresSafeArea()

            VStack(
                spacing: 16
            ) {

                Text("gru")
                    .font(
                        .system(
                            size: 32,
                            weight: .semibold
                        )
                    )
                    .foregroundStyle(
                        GRUColors.text
                    )

                ProgressView()
            }
        }
    }
}

// MARK: - Preview

#Preview {

    RootView()
}
