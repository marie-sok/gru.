import SwiftUI
import UIKit

@MainActor
struct SettingsView: View {
    @AppStorage("showStatus") private var showStatus = true
    @AppStorage("darkTheme") private var darkTheme = true
    @AppStorage("sounds") private var sounds = true

    @StateObject private var profile = ProfileStorage.shared
    @Bindable private var service = ChatService.shared

    var body: some View {
        NavigationStack {
            ZStack {
                GRUColors.background
                    .ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 20) {
                        NavigationLink {
                            ProfileView()
                        } label: {
                            profileCard
                        }
                        .buttonStyle(.plain)

                        settingsSection
                        Spacer(minLength: 120)
                    }
                    .padding(20)
                }
            }
            .navigationTitle("Настройки")
            .navigationBarTitleDisplayMode(.large)
        }
    }
}

private extension SettingsView {
    var profileCard: some View {
        HStack(spacing: 14) {
            avatar
                .frame(width: 64, height: 64)
                .clipShape(Circle())
                .overlay {
                    Circle().stroke(GRUColors.accent.opacity(0.36), lineWidth: 1)
                }
                .shadow(color: GRUColors.accent.opacity(0.18), radius: 9)

            VStack(alignment: .leading, spacing: 4) {
                Text(service.currentUser.displayName)
                    .font(.headline)
                Text("@\(profile.username)")
                    .font(.subheadline)
                    .foregroundStyle(GRUColors.accent)
            }

            Spacer()
            GRUNeonIcon(systemName: "chevron.right", size: 34, iconSize: 13)
        }
        .padding(14)
        .background(GRUColors.card)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    @ViewBuilder
    var avatar: some View {
        if let data = profile.avatarData,
           let image = UIImage(data: data) {
            Image(uiImage: image)
                .resizable()
                .scaledToFill()
        } else {
            ZStack {
                Circle().fill(GRUColors.accent.opacity(0.13))
                Image(systemName: "person.fill")
                    .foregroundStyle(GRUColors.accent)
            }
        }
    }

    var settingsSection: some View {
        VStack(spacing: 14) {
            settingToggle(
                title: "Показывать статус",
                icon: "dot.radiowaves.left.and.right",
                value: $showStatus
            )

            settingToggle(
                title: "Темная тема",
                icon: "moon.fill",
                value: $darkTheme
            )

            settingToggle(
                title: "Звуки",
                icon: "speaker.wave.2.fill",
                value: $sounds
            )
        }
    }

    func settingToggle(title: String, icon: String, value: Binding<Bool>) -> some View {
        HStack(spacing: 12) {
            GRUNeonIcon(systemName: icon, size: 36, iconSize: 14)
            Text(title)
            Spacer()
            Toggle("", isOn: value)
                .labelsHidden()
        }
        .padding(12)
        .background(GRUColors.card)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

#Preview { SettingsView() }
