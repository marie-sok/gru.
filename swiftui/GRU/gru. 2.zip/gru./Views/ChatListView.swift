
import SwiftUI

@MainActor
struct ChatListView: View {

    // MARK: - Services

    @State
    private var service = ChatService.shared

    // MARK: - New Chat

    @State
    private var showingNewChat = false

    // MARK: - Realtime

    @State
    private var realtimeListeners:
        [String: UUID] = [:]

    // MARK: - Body

    var body: some View {

        NavigationStack {

            ZStack {

                GRUColors.background
                    .ignoresSafeArea()

                content
            }
            .toolbar {

                // MARK: Logo

                ToolbarItem(
                    placement: .principal
                ) {

                    Text("gru")
                        .font(
                            .custom(
                                "AvenirNext-DemiBold",
                                size: 25
                            )
                        )
                        .tracking(-0.7)
                }

                // MARK: New Chat

                ToolbarItem(
                    placement: .topBarTrailing
                ) {

                    GRUNeonIconButton(
                        systemName: "envelope.fill",
                        accessibilityLabel: "Новый чат",
                        size: 38,
                        iconSize: 15
                    ) {
                        showingNewChat = true
                    }
                }
            }
            .navigationBarTitleDisplayMode(
                .inline
            )
        }

        // MARK: New Chat Sheet

        .sheet(
            isPresented:
                $showingNewChat,
            onDismiss: {

                Task {

                    await service.loadChats()

                    syncRealtimeSubscriptions()

                    connectWebSocket()
                }
            }
        ) {

            NewChatView()
        }

        // MARK: Initial Load

        .task {

            await loadData()
        }
    }

    // MARK: - Initial Load

    private func loadData() async {

        await service.loadChats()


        syncRealtimeSubscriptions()

  

        connectWebSocket()
    }

    // MARK: - WebSocket Connect

    private func connectWebSocket() {

        guard let token =
                TokenStorage.shared.token
        else {

            print("")
            print(
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            )
            print(
                "❌ WebSocket: JWT token not found"
            )
            print(
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            )

            return
        }

        WebSocketService.shared.connect(
            token: token
        )
    }

    // MARK: - Synchronize Realtime Subscriptions

    private func syncRealtimeSubscriptions() {

        let serverChatIDs =
            Set(
                service.chats.compactMap {
                    $0.serverID
                }
            )

        // MARK: Remove obsolete listeners

        let oldChatIDs =
            Array(
                realtimeListeners.keys
            )

        for chatID in oldChatIDs {

            guard
                !serverChatIDs.contains(
                    chatID
                ),
                let listenerID =
                    realtimeListeners[
                        chatID
                    ]
            else {

                continue
            }

            WebSocketService.shared
                .removeListener(
                    chatID: chatID,
                    listenerID: listenerID
                )

            realtimeListeners[
                chatID
            ] = nil

            print(
                "🧹 Realtime listener removed:",
                chatID
            )
        }

        // MARK: Add new listeners

        for chat in service.chats {

            guard let chatID =
                    chat.serverID
            else {

                continue
            }

            guard
                realtimeListeners[
                    chatID
                ] == nil
            else {

                continue
            }

            let listenerID =
                WebSocketService.shared
                    .addListener(
                        chatID: chatID
                    ) { message in

                        handleRealtimeMessage(
                            message
                        )
                    }

            realtimeListeners[
                chatID
            ] = listenerID

            print(
                "➕ Global realtime listener:",
                chatID
            )
        }
    }

    // MARK: - Global Realtime Message

    private func handleRealtimeMessage(
        _ message: ServerMessageDTO
    ) {

        print("")
        print(
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        )
        print(
            "🔥 CHAT LIST REALTIME MESSAGE"
        )
        print(
            "💬 chatId:",
            message.chatId
        )
        print(
            "🆔 messageId:",
            message.id
        )
        print(
            "👤 senderId:",
            message.senderId
        )
        print(
            "🎯 receiverId:",
            message.receiverId ?? "nil"
        )
        print(
            "💬 text:",
            message.text
        )
        print(
            "📬 deliveredAt:",
            message.deliveredAt
                .map {
                    String(
                        describing: $0
                    )
                }
                ?? "nil"
        )
        print(
            "👀 readAt:",
            message.readAt
                .map {
                    String(
                        describing: $0
                    )
                }
                ?? "nil"
        )
        print(
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        )

        /*
         Если это сообщение пришло НАМ
         и сервер ещё не считает его
         доставленным — отмечаем delivered.
         */

        markDeliveredIfNeeded(
            message
        )
    }

    // MARK: - Mark Delivered

    private func markDeliveredIfNeeded(
        _ message: ServerMessageDTO
    ) {

        guard let currentUserID =
                service.currentUser.serverID
        else {

            return
        }

        /*
         Не отмечаем delivered
         для собственных исходящих.
         */

        guard
            message.receiverId ==
                currentUserID
        else {

            return
        }

        /*
         Уже прочитанное сообщение
         автоматически является
         и доставленным.
         */

        guard
            message.readAt == nil
        else {

            return
        }

        /*
         Если deliveredAt уже есть,
         второй POST не нужен.

         Это также предотвращает цикл:
         POST delivered
         → WebSocket broadcast
         → POST delivered
         → ...
         */

        guard
            message.deliveredAt == nil
        else {

            return
        }

        guard let token =
                TokenStorage.shared.token
        else {

            return
        }

        Task {

            do {

                let updatedMessage =
                    try await MessageAPIService.shared
                        .markDelivered(
                            messageID:
                                message.id,
                            token:
                                token
                        )

                print("")
                print(
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                )
                print(
                    "📬 MESSAGE DELIVERED"
                )
                print(
                    "🆔",
                    updatedMessage.id
                )
                print(
                    "💬",
                    updatedMessage.text
                )
                print(
                    "📬 deliveredAt:",
                    updatedMessage
                        .deliveredAt
                        .map {
                            String(
                                describing: $0
                            )
                        }
                        ?? "nil"
                )
                print(
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                )

            } catch {

                print("")
                print(
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                )
                print(
                    "❌ Mark delivered error"
                )
                print(
                    error.localizedDescription
                )
                print(
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                )
            }
        }
    }

    // MARK: - Content

    @ViewBuilder
    private var content: some View {

        if service.isLoadingChats &&
            service.chats.isEmpty {

            loadingView

        } else if
            let error =
                service.chatLoadingError,
            service.chats.isEmpty {

            errorView(
                message: error
            )

        } else if
            service.chats.isEmpty {

            emptyView

        } else {

            chatList
        }
    }

    // MARK: - Chat List

    private var chatList: some View {

        List {

            ForEach(
                service.chats
            ) { chat in

                NavigationLink {

                    ChatView(
                        chat: chat
                    )

                } label: {

                    ChatRow(
                        chat: chat
                    )
                }
            }
        }
        .listStyle(
            .plain
        )
        .scrollContentBackground(
            .hidden
        )
        .background(
            Color.clear
        )
        .refreshable {

            await service.loadChats()

            syncRealtimeSubscriptions()

            connectWebSocket()
        }
    }

    // MARK: - Empty

    private var emptyView: some View {

        VStack(
            spacing: 18
        ) {

            Spacer()

            GRUEnvelope()
                .stroke(
                    GRUColors.accent,
                    style:
                        StrokeStyle(
                            lineWidth: 1.6,
                            lineCap: .round,
                            lineJoin: .round
                        )
                )
                .frame(
                    width: 38,
                    height: 27
                )
                .opacity(
                    0.8
                )

            VStack(
                spacing: 6
            ) {

                Text(
                    "Пока тихо"
                )
                .font(
                    .system(
                        size: 21,
                        weight: .semibold,
                        design: .rounded
                    )
                )

                Text(
                    "Начни первую переписку"
                )
                .font(
                    .system(
                        size: 14,
                        weight: .regular,
                        design: .rounded
                    )
                )
                .foregroundStyle(
                    .secondary
                )
            }

            Button {

                showingNewChat = true

            } label: {

                HStack(
                    spacing: 8
                ) {

                    GRUNeonIcon(
                        systemName: "envelope.fill",
                        size: 30,
                        iconSize: 12
                    )

                    Text(
                        "Новый чат"
                    )
                    .font(
                        .system(
                            size: 15,
                            weight: .semibold,
                            design: .rounded
                        )
                    )
                }
                .foregroundStyle(
                    GRUColors.accent
                )
                .padding(
                    .horizontal,
                    18
                )
                .frame(
                    height: 44
                )
                .background(
                    GRUColors.card
                )
                .clipShape(
                    Capsule()
                )
            }
            .buttonStyle(
                .plain
            )

            Spacer()
        }
        .padding(
            .horizontal,
            24
        )
    }

    // MARK: - Loading

    private var loadingView: some View {

        VStack(
            spacing: 12
        ) {

            ProgressView()

            Text(
                "Загрузка…"
            )
            .font(
                .system(
                    size: 14,
                    design: .rounded
                )
            )
            .foregroundStyle(
                .secondary
            )
        }
    }

    // MARK: - Error

    private func errorView(
        message: String
    ) -> some View {

        VStack(
            spacing: 14
        ) {

            Spacer()

            Image(
                systemName:
                    "wifi.exclamationmark"
            )
            .font(
                .system(
                    size: 29,
                    weight: .light
                )
            )

            Text(
                "Не удалось загрузить чаты"
            )
            .font(
                .system(
                    size: 18,
                    weight: .semibold,
                    design: .rounded
                )
            )

            Text(
                message
            )
            .font(
                .system(
                    size: 13,
                    design: .rounded
                )
            )
            .foregroundStyle(
                .secondary
            )
            .multilineTextAlignment(
                .center
            )

            Button(
                "Повторить"
            ) {

                Task {

                    await service.loadChats()

                    syncRealtimeSubscriptions()

                    connectWebSocket()
                }
            }
            .buttonStyle(
                .bordered
            )

            Spacer()
        }
        .padding(
            .horizontal,
            30
        )
    }
}

// MARK: - Preview

#Preview {

    ChatListView()
}
