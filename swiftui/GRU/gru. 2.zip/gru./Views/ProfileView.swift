import PhotosUI
import SwiftUI
import UIKit

@MainActor
struct ProfileView: View {
    @Environment(\.dismiss) private var dismiss

    @Bindable private var service = ChatService.shared
    @StateObject private var profile = ProfileStorage.shared

    @State private var selectedAvatar: PhotosPickerItem?
    @State private var notifications = true
    @State private var darkMode = true

    var body: some View {
        NavigationStack {
            ZStack {
                ChatBackgroundView(style: .obsidian)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        avatarSection
                        identitySection
                        bioSection
                        savedVideoNotesSection
                        settingsSection
                        Spacer(minLength: 30)
                    }
                    .padding(18)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    GRUNeonIconButton(
                        systemName: "chevron.left",
                        accessibilityLabel: "Назад",
                        size: 36,
                        iconSize: 14
                    ) {
                        dismiss()
                    }
                }

                ToolbarItem(placement: .principal) {
                    Text("Профиль")
                        .font(.headline)
                }
            }
        }
        .onAppear {
            service.currentUser.username = profile.username
        }
        .onChange(of: profile.username) { _, value in
            service.currentUser.username = value
        }
        .onChange(of: selectedAvatar) { _, item in
            guard let item else { return }

            Task {
                do {
                    guard let data = try await item.loadTransferable(type: Data.self),
                          let image = UIImage(data: data),
                          let jpeg = image.jpegData(compressionQuality: 0.82)
                    else {
                        return
                    }

                    await MainActor.run {
                        profile.avatarData = jpeg
                        selectedAvatar = nil
                    }
                } catch {
                    print("❌ Avatar picker error:", error)
                }
            }
        }
    }
}

private extension ProfileView {
    var avatarSection: some View {
        VStack(spacing: 14) {
            ZStack(alignment: .bottomTrailing) {
                avatarImage
                    .frame(width: 112, height: 112)
                    .clipShape(Circle())
                    .overlay {
                        Circle()
                            .stroke(
                                LinearGradient(
                                    colors: [
                                        GRUColors.accent,
                                        .white.opacity(0.66),
                                        GRUColors.accent.opacity(0.58)
                                    ],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ),
                                lineWidth: 2
                            )
                    }
                    .shadow(color: GRUColors.accent.opacity(0.34), radius: 18)

                PhotosPicker(selection: $selectedAvatar, matching: .images) {
                    GRUNeonIcon(systemName: "camera.fill", size: 38, iconSize: 15)
                }
                .buttonStyle(.plain)
            }

            Text(service.currentUser.displayName)
                .font(.title2.bold())

            Text("@\(profile.username)")
                .font(.subheadline.weight(.medium))
                .foregroundStyle(GRUColors.accent)
        }
        .padding(.top, 8)
    }

    @ViewBuilder
    var avatarImage: some View {
        if let data = profile.avatarData,
           let image = UIImage(data: data) {
            Image(uiImage: image)
                .resizable()
                .scaledToFill()
        } else {
            ZStack {
                Circle()
                    .fill(GRUColors.accent.opacity(0.14))
                Image(systemName: "person.fill")
                    .font(.system(size: 42, weight: .bold))
                    .foregroundStyle(GRUColors.accent)
            }
        }
    }

    var identitySection: some View {
        VStack(spacing: 12) {
            fieldRow(
                icon: "at",
                title: "Username"
            ) {
                TextField("Username", text: $profile.username)
                    .multilineTextAlignment(.trailing)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }

            profileRow(
                icon: "circle.fill",
                title: "Статус",
                value: service.currentUser.isOnline ? "Online" : "Offline"
            )
        }
    }

    var bioSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                GRUNeonIcon(systemName: "quote.bubble.fill", size: 34, iconSize: 14)
                Text("О себе")
                    .font(.headline)
                Spacer()
                Text("\(profile.bio.count)/160")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            TextEditor(text: $profile.bio)
                .frame(minHeight: 90)
                .scrollContentBackground(.hidden)
                .padding(10)
                .background(GRUColors.card.opacity(0.92))
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .stroke(GRUColors.accent.opacity(0.10), lineWidth: 1)
                }
                .onChange(of: profile.bio) { _, value in
                    if value.count > 160 {
                        profile.bio = String(value.prefix(160))
                    }
                }
        }
    }

    var savedVideoNotesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                GRUNeonIcon(systemName: "pawprint.fill", size: 34, iconSize: 14)
                Text("Сохранённые кружки")
                    .font(.headline)
                Spacer()
                Text("\(profile.savedVideoNotes.count)")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
            }

            if profile.savedVideoNotes.isEmpty {
                Text("Сохраняй кружки из меню сообщения — они появятся здесь.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(16)
                    .background(GRUColors.card.opacity(0.72))
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 14) {
                        ForEach(profile.savedVideoNotes) { note in
                            VStack(spacing: 8) {
                                VideoNoteBubble(attachment: note.attachment)

                                Button(role: .destructive) {
                                    profile.removeVideoNote(note)
                                } label: {
                                    HStack(spacing: 6) {
                                        GRUNeonIcon(
                                            systemName: "bookmark.slash.fill",
                                            size: 28,
                                            iconSize: 11
                                        )
                                        Text("Убрать")
                                            .font(.caption.weight(.medium))
                                    }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(.vertical, 8)
                }
            }
        }
    }

    var settingsSection: some View {
        VStack(spacing: 12) {
            toggleRow(
                icon: "bell.fill",
                title: "Уведомления",
                value: $notifications
            )

            toggleRow(
                icon: "moon.fill",
                title: "Темная тема",
                value: $darkMode
            )
        }
    }

    func profileRow(icon: String, title: String, value: String) -> some View {
        HStack(spacing: 12) {
            GRUNeonIcon(systemName: icon, size: 36, iconSize: 14)
            Text(title)
            Spacer()
            Text(value)
                .foregroundStyle(.secondary)
        }
        .padding(12)
        .background(GRUColors.card.opacity(0.88))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    func fieldRow<Content: View>(
        icon: String,
        title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        HStack(spacing: 12) {
            GRUNeonIcon(systemName: icon, size: 36, iconSize: 14)
            Text(title)
            Spacer()
            content()
                .foregroundStyle(.secondary)
        }
        .padding(12)
        .background(GRUColors.card.opacity(0.88))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    func toggleRow(icon: String, title: String, value: Binding<Bool>) -> some View {
        HStack(spacing: 12) {
            GRUNeonIcon(systemName: icon, size: 36, iconSize: 14)
            Text(title)
            Spacer()
            Toggle("", isOn: value)
                .labelsHidden()
        }
        .padding(12)
        .background(GRUColors.card.opacity(0.88))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

#Preview { ProfileView() }
