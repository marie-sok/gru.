import SwiftUI

struct MainView: View {
    @State private var selectedTab: AppTab = .chats

    var body: some View {
        ZStack(alignment: .bottom) {
            GRUColors.background
                .ignoresSafeArea()

            Group {
                switch selectedTab {
                case .contacts:
                    ContactsView()
                case .chats:
                    ChatListView()
                case .settings:
                    SettingsView()
                }
            }

            GRUTabBar(selectedTab: $selectedTab)
                .padding(.bottom, 12)
        }
        .ignoresSafeArea(.keyboard)
    }
}

#Preview { MainView() }
