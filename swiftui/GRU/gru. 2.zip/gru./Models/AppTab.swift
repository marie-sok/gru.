enum AppTab: CaseIterable {
    case contacts
    case chats
    case settings
}
