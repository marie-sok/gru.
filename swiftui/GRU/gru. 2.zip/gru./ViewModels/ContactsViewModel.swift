import Contacts
import Foundation
import Combine

struct PhoneContact: Identifiable, Hashable {
    let id: String
    let givenName: String
    let familyName: String
    let phoneNumbers: [String]

    var displayName: String {
        let full = [givenName, familyName]
            .filter { !$0.isEmpty }
            .joined(separator: " ")
        return full.isEmpty ? "Без имени" : full
    }

    var primaryPhone: String? {
        phoneNumbers.first
    }

    var initials: String {
        let parts = displayName.split(separator: " ")
        return parts.prefix(2).compactMap { $0.first }.map(String.init).joined()
    }
}

enum PhoneContactsAccessState: Equatable {
    case unknown
    case loading
    case granted
    case denied
}

@MainActor
final class ContactsViewModel: ObservableObject {
    @Published var phoneContacts: [PhoneContact] = []
    @Published var searchText = ""
    @Published var accessState: PhoneContactsAccessState = .unknown
    @Published var errorText: String?

    private let store = CNContactStore()

    var filteredPhoneContacts: [PhoneContact] {
        let query = normalizedSearch
        guard !query.isEmpty else { return phoneContacts }

        return phoneContacts.filter { contact in
            contact.displayName.localizedCaseInsensitiveContains(query) ||
            contact.phoneNumbers.contains { $0.localizedCaseInsensitiveContains(query) }
        }
    }

    var normalizedSearch: String {
        searchText.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func loadPhoneContacts() async {
        accessState = .loading
        errorText = nil

        let status = CNContactStore.authorizationStatus(for: .contacts)

        switch status {
        case .authorized:
            fetchContacts()

        case .limited:
            fetchContacts()

        case .notDetermined:
            let granted = await requestAccess()
            if granted {
                fetchContacts()
            } else {
                accessState = .denied
            }

        case .denied, .restricted:
            accessState = .denied

        @unknown default:
            accessState = .denied
        }
    }

    private func requestAccess() async -> Bool {
        await withCheckedContinuation { continuation in
            store.requestAccess(for: .contacts) { granted, _ in
                continuation.resume(returning: granted)
            }
        }
    }

    private func fetchContacts() {
        let keys: [CNKeyDescriptor] = [
            CNContactIdentifierKey as CNKeyDescriptor,
            CNContactGivenNameKey as CNKeyDescriptor,
            CNContactFamilyNameKey as CNKeyDescriptor,
            CNContactPhoneNumbersKey as CNKeyDescriptor
        ]

        let request = CNContactFetchRequest(keysToFetch: keys)
        request.sortOrder = .userDefault

        var values: [PhoneContact] = []

        do {
            try store.enumerateContacts(with: request) { contact, _ in
                let phones = contact.phoneNumbers
                    .map { $0.value.stringValue }
                    .filter { !$0.isEmpty }

                guard !phones.isEmpty else { return }

                values.append(
                    PhoneContact(
                        id: contact.identifier,
                        givenName: contact.givenName,
                        familyName: contact.familyName,
                        phoneNumbers: phones
                    )
                )
            }

            phoneContacts = values
            accessState = .granted
        } catch {
            phoneContacts = []
            accessState = .denied
            errorText = error.localizedDescription
        }
    }
}
