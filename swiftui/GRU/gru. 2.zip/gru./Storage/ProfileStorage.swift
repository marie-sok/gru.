import Combine
import Foundation

struct SavedVideoNote: Identifiable, Codable, Hashable {
    static func == (lhs: SavedVideoNote, rhs: SavedVideoNote) -> Bool {
        lhs.id == rhs.id &&
            lhs.sourceKey == rhs.sourceKey &&
            lhs.attachment == rhs.attachment &&
            lhs.savedAt == rhs.savedAt
    }

    let id: UUID
    let sourceKey: String
    var attachment: Attachment
    let savedAt: Date

    init(
        id: UUID = UUID(),
        sourceKey: String,
        attachment: Attachment,
        savedAt: Date = Date()
    ) {
        self.id = id
        self.sourceKey = sourceKey
        self.attachment = attachment
        self.savedAt = savedAt
    }
}

@MainActor
final class ProfileStorage: ObservableObject {
    static let shared = ProfileStorage()

    private enum Keys {
        static let username = "gru.profile.username"
        static let bio = "gru.profile.bio"
        static let avatarData = "gru.profile.avatarData"
        static let savedVideoNotes = "gru.profile.savedVideoNotes.v2"
        static let usernameMigration = "gru.profile.username.marie-sok.v1"
    }

    @Published var username: String {
        didSet {
            let clean = username.trimmingCharacters(in: .whitespacesAndNewlines)
            let normalized = clean.isEmpty ? "marie.sok" : clean
            if username != normalized {
                username = normalized
                return
            }
            UserDefaults.standard.set(normalized, forKey: Keys.username)
        }
    }

    @Published var bio: String {
        didSet {
            if bio.count > 160 {
                bio = String(bio.prefix(160))
                return
            }
            UserDefaults.standard.set(bio, forKey: Keys.bio)
        }
    }

    @Published var avatarData: Data? {
        didSet {
            UserDefaults.standard.set(avatarData, forKey: Keys.avatarData)
        }
    }

    @Published private(set) var savedVideoNotes: [SavedVideoNote]

    private init() {
        let defaults = UserDefaults.standard

        // The user explicitly requested this nickname. Force it once so an old
        // cached username from previous GRU builds cannot hide the change.
        if !defaults.bool(forKey: Keys.usernameMigration) {
            defaults.set("marie.sok", forKey: Keys.username)
            defaults.set(true, forKey: Keys.usernameMigration)
        }

        let storedUsername = defaults.string(forKey: Keys.username)
        username = (storedUsername?.isEmpty == false) ? storedUsername! : "marie.sok"
        bio = defaults.string(forKey: Keys.bio) ?? ""
        avatarData = defaults.data(forKey: Keys.avatarData)

        if let data = defaults.data(forKey: Keys.savedVideoNotes),
           let decoded = try? JSONDecoder().decode([SavedVideoNote].self, from: data) {
            savedVideoNotes = decoded.sorted { $0.savedAt > $1.savedAt }
        } else {
            savedVideoNotes = []
        }
    }

    func isVideoNoteSaved(_ message: Message) -> Bool {
        let key = sourceKey(for: message)
        return savedVideoNotes.contains { $0.sourceKey == key }
    }

    func saveVideoNote(_ message: Message) {
        guard let attachment = message.attachment,
              attachment.type == .videoNote
        else {
            return
        }

        let key = sourceKey(for: message)
        guard !savedVideoNotes.contains(where: { $0.sourceKey == key }) else {
            return
        }

        let persistentAttachment = makePersistentAttachment(from: attachment)
        let note = SavedVideoNote(
            sourceKey: key,
            attachment: persistentAttachment
        )

        savedVideoNotes.insert(note, at: 0)
        persistSavedVideoNotes()
    }

    func removeVideoNote(_ note: SavedVideoNote) {
        if let path = note.attachment.localPath,
           path.contains(savedDirectory.path) {
            try? FileManager.default.removeItem(atPath: path)
        }

        savedVideoNotes.removeAll { $0.id == note.id }
        persistSavedVideoNotes()
    }

    private func sourceKey(for message: Message) -> String {
        if let serverID = message.serverID, !serverID.isEmpty {
            return "server:\(serverID)"
        }
        return "local:\(message.id.uuidString)"
    }

    private var savedDirectory: URL {
        let base = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first!

        let directory = base
            .appendingPathComponent("GRU", isDirectory: true)
            .appendingPathComponent("SavedVideoNotes", isDirectory: true)

        try? FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true
        )

        return directory
    }

    private func makePersistentAttachment(from attachment: Attachment) -> Attachment {
        var result = attachment

        guard let localPath = attachment.localPath,
              !localPath.isEmpty,
              FileManager.default.fileExists(atPath: localPath)
        else {
            // remoteURL remains in the saved record, so a saved note can still
            // be downloaded even after its chat message is no longer loaded.
            return result
        }

        let sourceURL = URL(fileURLWithPath: localPath)
        let ext = sourceURL.pathExtension.isEmpty ? "mov" : sourceURL.pathExtension
        let destination = savedDirectory
            .appendingPathComponent("\(attachment.id.uuidString).\(ext)")

        do {
            if !FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.copyItem(at: sourceURL, to: destination)
            }
            result.localPath = destination.path
        } catch {
            print("❌ Save video note copy error:", error)
        }

        return result
    }

    private func persistSavedVideoNotes() {
        guard let data = try? JSONEncoder().encode(savedVideoNotes) else {
            return
        }
        UserDefaults.standard.set(data, forKey: Keys.savedVideoNotes)
    }
}
