import Foundation

final class LocalMessageDeletionStore {
    static let shared = LocalMessageDeletionStore()

    private let key = "gru.messages.hiddenLocally"
    private let defaults = UserDefaults.standard

    private init() {}

    func isHidden(_ serverMessageID: String) -> Bool {
        hiddenIDs.contains(serverMessageID)
    }

    func hide(_ serverMessageID: String) {
        guard !serverMessageID.isEmpty else { return }
        var values = hiddenIDs
        values.insert(serverMessageID)
        defaults.set(Array(values), forKey: key)
    }

    func unhide(_ serverMessageID: String) {
        var values = hiddenIDs
        values.remove(serverMessageID)
        defaults.set(Array(values), forKey: key)
    }

    private var hiddenIDs: Set<String> {
        Set(defaults.stringArray(forKey: key) ?? [])
    }
}
