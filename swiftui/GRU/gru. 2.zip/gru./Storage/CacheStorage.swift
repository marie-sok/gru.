//
//  CacheStorage.swift
//  gru.
//
//  Created by Maria Morozova on 06.07.2026.
//


import Foundation

final class CacheStorage {

    static let shared = CacheStorage()

    private init() {}

    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()

    private var chatsURL: URL {

        documentsDirectory
            .appendingPathComponent("chats.json")
    }

    private var usersURL: URL {

        documentsDirectory
            .appendingPathComponent("users.json")
    }

    private var documentsDirectory: URL {

        FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        )[0]
    }

    // MARK: - Chats

    func saveChats(
        _ chats: [Chat]
    ) {

        do {

            let data = try encoder.encode(chats)

            try data.write(to: chatsURL)

        } catch {

            print(error.localizedDescription)
        }
    }

    func loadChats() -> [Chat] {

        guard FileManager.default.fileExists(
            atPath: chatsURL.path
        ) else {

            return []
        }

        do {

            let data = try Data(
                contentsOf: chatsURL
            )

            return try decoder.decode(
                [Chat].self,
                from: data
            )

        } catch {

            print(error.localizedDescription)

            return []
        }
    }

    // MARK: - Users

    func saveUsers(
        _ users: [User]
    ) {

        do {

            let data = try encoder.encode(users)

            try data.write(to: usersURL)

        } catch {

            print(error.localizedDescription)
        }
    }

    func loadUsers() -> [User] {

        guard FileManager.default.fileExists(
            atPath: usersURL.path
        ) else {

            return []
        }

        do {

            let data = try Data(
                contentsOf: usersURL
            )

            return try decoder.decode(
                [User].self,
                from: data
            )

        } catch {

            print(error.localizedDescription)

            return []
        }
    }

    // MARK: - Clear

    func clear() {

        try? FileManager.default.removeItem(
            at: chatsURL
        )

        try? FileManager.default.removeItem(
            at: usersURL
        )
    }
}