//
//  SettingsStorage.swift
//  gru.
//
//  Created by Maria Morozova on 06.07.2026.
//


import Foundation

final class SettingsStorage {

    static let shared = SettingsStorage()

    private let defaults = UserDefaults.standard

    private init() {}

    enum Key: String {

        case darkMode
        case notifications
        case autoDownload
        case readReceipts
    }

    var darkMode: Bool {

        get {

            defaults.bool(
                forKey: Key.darkMode.rawValue
            )
        }

        set {

            defaults.set(
                newValue,
                forKey: Key.darkMode.rawValue
            )
        }
    }

    var notificationsEnabled: Bool {

        get {

            defaults.object(
                forKey: Key.notifications.rawValue
            ) as? Bool ?? true
        }

        set {

            defaults.set(
                newValue,
                forKey: Key.notifications.rawValue
            )
        }
    }

    var autoDownload: Bool {

        get {

            defaults.object(
                forKey: Key.autoDownload.rawValue
            ) as? Bool ?? true
        }

        set {

            defaults.set(
                newValue,
                forKey: Key.autoDownload.rawValue
            )
        }
    }

    var readReceipts: Bool {

        get {

            defaults.object(
                forKey: Key.readReceipts.rawValue
            ) as? Bool ?? true
        }

        set {

            defaults.set(
                newValue,
                forKey: Key.readReceipts.rawValue
            )
        }
    }
}