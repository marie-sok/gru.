import SwiftUI

struct GRUNeonIcon: View {
    let systemName: String
    var size: CGFloat = 40
    var iconSize: CGFloat = 17
    var isActive: Bool = true

    var body: some View {
        ZStack {
            Circle()
                .fill(GRUColors.card.opacity(0.94))

            Circle()
                .fill(GRUColors.accent.opacity(isActive ? 0.055 : 0.018))
                .padding(2)

            Circle()
                .stroke(
                    LinearGradient(
                        colors: [
                            GRUColors.accent.opacity(isActive ? 0.78 : 0.20),
                            Color.white.opacity(isActive ? 0.28 : 0.07),
                            Color.cyan.opacity(isActive ? 0.34 : 0.08),
                            GRUColors.accent.opacity(isActive ? 0.42 : 0.10)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: isActive ? 1.15 : 0.8
                )

            Image(systemName: systemName)
                .font(.system(size: iconSize, weight: .semibold))
                .foregroundStyle(isActive ? GRUColors.accent : .secondary)
                .shadow(
                    color: GRUColors.accent.opacity(isActive ? 0.36 : 0),
                    radius: isActive ? 4 : 0
                )
        }
        .frame(width: size, height: size)
        .shadow(
            color: GRUColors.accent.opacity(isActive ? 0.20 : 0.035),
            radius: isActive ? 9 : 3
        )
        .shadow(
            color: Color.cyan.opacity(isActive ? 0.055 : 0),
            radius: isActive ? 15 : 0
        )
    }
}

struct GRUNeonIconButton: View {
    let systemName: String
    var accessibilityLabel: String
    var size: CGFloat = 40
    var iconSize: CGFloat = 17
    var isActive: Bool = true
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            GRUNeonIcon(
                systemName: systemName,
                size: size,
                iconSize: iconSize,
                isActive: isActive
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel(accessibilityLabel)
    }
}
