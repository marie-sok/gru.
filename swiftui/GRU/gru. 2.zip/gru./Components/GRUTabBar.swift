import SwiftUI

struct GRUTabBar: View {
    @Binding var selectedTab: AppTab

    var body: some View {
        HStack(spacing: 34) {
            item(.contacts, image: "person.2.fill", label: "Люди")
            chatsButton
            item(.settings, image: "gearshape.fill", label: "Настройки")
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 24)
        .frame(height: 70)
        .background(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(GRUColors.card.opacity(0.94))
                .overlay {
                    RoundedRectangle(cornerRadius: 28, style: .continuous)
                        .stroke(GRUColors.accent.opacity(0.10), lineWidth: 1)
                }
                .shadow(color: GRUColors.accent.opacity(0.09), radius: 22, y: 7)
        )
        .padding(.horizontal, 20)
    }

    private func item(_ tab: AppTab, image: String, label: String) -> some View {
        Button {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) {
                selectedTab = tab
            }
        } label: {
            GRUNeonIcon(
                systemName: image,
                size: 46,
                iconSize: 18,
                isActive: selectedTab == tab
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }

    private var chatsButton: some View {
        Button {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) {
                selectedTab = .chats
            }
        } label: {
            ZStack {
                Circle()
                    .fill(GRUColors.card)
                Circle()
                    .stroke(
                        LinearGradient(
                            colors: [
                                GRUColors.accent.opacity(selectedTab == .chats ? 0.95 : 0.22),
                                Color.white.opacity(selectedTab == .chats ? 0.28 : 0.08),
                                GRUColors.accent.opacity(selectedTab == .chats ? 0.48 : 0.12)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: selectedTab == .chats ? 1.5 : 1
                    )

                GRUEnvelope()
                    .stroke(
                        selectedTab == .chats ? GRUColors.accent : GRUColors.secondary,
                        style: StrokeStyle(lineWidth: 2.1, lineJoin: .round)
                    )
                    .frame(width: 23, height: 17)
            }
            .frame(width: 50, height: 50)
            .shadow(
                color: GRUColors.accent.opacity(selectedTab == .chats ? 0.34 : 0.06),
                radius: selectedTab == .chats ? 11 : 4
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Чаты")
    }
}

#Preview {
    GRUTabBar(selectedTab: .constant(.chats))
        .padding()
}
