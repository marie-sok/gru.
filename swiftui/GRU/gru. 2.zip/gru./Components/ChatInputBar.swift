import SwiftUI
import UIKit

@MainActor
struct ChatInputBar: View {

    @Binding
    var text: String

    @Binding
    var sendTrigger: Bool

    var onSend: () -> Void

    var onAttachment:
        (AttachmentAction) -> Void

    /// Called after a hold-to-record voice message is finished.
    /// The receiver owns the temporary file and deletes it
    /// after upload.
    var onAudioRecorded:
        (VoiceAudioRecording) -> Void = { _ in }

    @State
    private var showMenu =
        false

    @State
    private var isSending =
        false

    @StateObject
    private var audioRecorder =
        VoiceAudioRecorderModel()

    @State
    private var isMicPressed =
        false

    @State
    private var isInlineRecording =
        false

    @State
    private var cancelRecording =
        false

    private let cancelThreshold:
        CGFloat =
        -72

    private var canSend: Bool {
        !text
            .trimmingCharacters(
                in:
                    .whitespacesAndNewlines
            )
            .isEmpty
    }

    private var isAudioBusy: Bool {
        isMicPressed ||
        isInlineRecording ||
        audioRecorder.isRecording ||
        audioRecorder.isPreparing
    }

    var body: some View {
        VStack(
            spacing: 0
        ) {
            if
                showMenu,
                !isAudioBusy
            {
                AttachmentMenu {
                    action in

                    withAnimation(
                        .spring(
                            response:
                                0.3,
                            dampingFraction:
                                0.8
                        )
                    ) {
                        showMenu =
                            false
                    }

                    onAttachment(
                        action
                    )
                }
                .transition(
                    .move(
                        edge:
                            .bottom
                    )
                    .combined(
                        with:
                            .opacity
                    )
                )
            }

            HStack(
                spacing: 10
            ) {
                attachmentButton

                if isAudioBusy {
                    recordingStrip
                        .transition(
                            .opacity
                            .combined(
                                with:
                                    .scale(
                                        scale:
                                            0.98
                                    )
                            )
                        )
                } else {
                    textField
                        .transition(
                            .opacity
                        )
                }

                if canSend,
                   !isAudioBusy {
                    sendButton
                        .transition(
                            .scale
                            .combined(
                                with:
                                    .opacity
                            )
                        )
                } else {
                    microphoneButton
                        .transition(
                            .scale
                            .combined(
                                with:
                                    .opacity
                            )
                        )
                }
            }
            .padding(
                .horizontal,
                14
            )
            .padding(
                .vertical,
                9
            )
            .background(
                .ultraThinMaterial
            )
            .animation(
                .spring(
                    response:
                        0.25,
                    dampingFraction:
                        0.82
                ),
                value:
                    isAudioBusy
            )
            .animation(
                .easeInOut(
                    duration:
                        0.16
                ),
                value:
                    canSend
            )
        }
        .onDisappear {
            isMicPressed =
                false

            if
                audioRecorder.isRecording ||
                audioRecorder.isPreparing
            {
                audioRecorder
                    .cancel()
            }
        }
    }

    // MARK: - Attachments

    private var attachmentButton:
        some View
    {
        Button {
            guard
                !isAudioBusy
            else {
                return
            }

            withAnimation(
                .spring(
                    response:
                        0.3,
                    dampingFraction:
                        0.8
                )
            ) {
                showMenu.toggle()
            }

        } label: {
            GRUNeonIcon(
                systemName: showMenu ? "xmark" : "plus",
                size: 40,
                iconSize: 18,
                isActive: !isAudioBusy
            )
        }
        .buttonStyle(
            .plain
        )
        .disabled(
            isAudioBusy
        )
    }

    // MARK: - Text

    private var textField:
        some View
    {
        TextField(
            "Сообщение",
            text:
                $text,
            axis:
                .vertical
        )
        .textFieldStyle(
            .plain
        )
        .lineLimit(
            1...6
        )
        .padding(
            .horizontal,
            16
        )
        .padding(
            .vertical,
            11
        )
        .background(
            GRUColors.card
        )
        .clipShape(
            RoundedRectangle(
                cornerRadius:
                    21,
                style:
                    .continuous
            )
        )
    }

    // MARK: - Recording Strip

    private var recordingStrip:
        some View
    {
        HStack(
            spacing: 9
        ) {
            Image(
                systemName:
                    cancelRecording
                    ? "xmark"
                    : (
                        audioRecorder
                            .isRecording
                        ? "waveform"
                        : "mic.fill"
                    )
            )
            .font(
                .system(
                    size:
                        15,
                    weight:
                        .semibold
                )
            )
            .foregroundStyle(
                cancelRecording
                ? Color.red
                : GRUColors.accent
            )
            .frame(
                width:
                    20
            )

            if cancelRecording {
                Text(
                    "Отпусти — отменим"
                )
                .font(
                    .system(
                        size:
                            13,
                        weight:
                            .semibold,
                        design:
                            .rounded
                    )
                )
                .foregroundStyle(
                    .red
                )
                .lineLimit(
                    1
                )

                Spacer(
                    minLength:
                        0
                )
            } else {
                VoiceWaveform(
                    samples:
                        audioRecorder
                            .waveform,
                    progress:
                        1,
                    barWidth:
                        2.5,
                    spacing:
                        1.8
                )
                .frame(
                    minWidth:
                        62,
                    maxWidth:
                        .infinity
                )
                .frame(
                    height:
                        28
                )

                Text(
                    audioRecorder
                        .elapsedText
                )
                .font(
                    .system(
                        size:
                            12,
                        weight:
                            .semibold,
                        design:
                            .rounded
                    )
                )
                .monospacedDigit()
                .foregroundStyle(
                    .secondary
                )
            }
        }
        .padding(
            .horizontal,
            13
        )
        .frame(
            minHeight:
                42
        )
        .background(
            GRUColors.card
        )
        .clipShape(
            RoundedRectangle(
                cornerRadius:
                    21,
                style:
                    .continuous
            )
        )
        .overlay {
            RoundedRectangle(
                cornerRadius:
                    21,
                style:
                    .continuous
            )
            .stroke(
                cancelRecording
                ? Color.red
                    .opacity(
                        0.42
                    )
                : GRUColors.accent
                    .opacity(
                        audioRecorder
                            .isRecording
                        ? 0.22
                        : 0.10
                    ),
                lineWidth:
                    1
            )
        }
    }

    // MARK: - Envelope

    private var sendButton:
        some View
    {
        Button {
            sendMessage()
        } label: {
            GRUNeonIcon(
                systemName: "envelope.fill",
                size: 42,
                iconSize: 20
            )
            .scaleEffect(isSending ? 0.82 : 1)
            .rotationEffect(.degrees(isSending ? -7 : 0))
        }
        .buttonStyle(
            .plain
        )
        .accessibilityLabel(
            "Отправить"
        )
    }

    // MARK: - Hold Mic

    private var microphoneButton:
        some View
    {
        GRUNeonIcon(
            systemName:
                audioRecorder.isRecording
                ? "waveform"
                : "mic.fill",
            size: 42,
            iconSize:
                audioRecorder.isRecording
                ? 19
                : 18,
            isActive: !cancelRecording
        )
        .overlay {
            if cancelRecording {
                Circle()
                    .stroke(Color.red.opacity(0.72), lineWidth: 1.5)
                    .shadow(color: Color.red.opacity(0.32), radius: 7)
            }
        }
        .foregroundStyle(cancelRecording ? Color.red : GRUColors.accent)
        .scaleEffect(isMicPressed ? 1.10 : 1)
        .contentShape(Circle())
        .onLongPressGesture(
            minimumDuration: 0.18,
            maximumDistance: .infinity,
            pressing: { pressing in
                if pressing {
                    beginMicTouch()
                } else {
                    finishMicPress()
                }
            },
            perform: {
                startInlineRecording()
            }
        )
        .simultaneousGesture(cancelDragGesture)
        .animation(
            .spring(response: 0.22, dampingFraction: 0.72),
            value: isMicPressed
        )
        .animation(
            .easeInOut(duration: 0.12),
            value: cancelRecording
        )
        .accessibilityLabel("Удерживай для голосового")
    }

    private var cancelDragGesture:
        some Gesture
    {
        DragGesture(
            minimumDistance:
                8,
            coordinateSpace:
                .local
        )
        .onChanged {
            value in

            guard
                isInlineRecording ||
                audioRecorder
                    .isRecording
            else {
                return
            }

            let shouldCancel =
                value.translation
                    .width <=
                cancelThreshold

            if
                shouldCancel !=
                cancelRecording
            {
                cancelRecording =
                    shouldCancel

                if shouldCancel {
                    UIImpactFeedbackGenerator(
                        style:
                            .light
                    )
                    .impactOccurred()
                }
            }
        }
        .onEnded {
            _ in

            // Release itself is handled by the long-press
            // `pressing` callback. This gesture only tracks
            // the slide-left cancel threshold.
        }
    }

    private func beginMicTouch() {
        guard
            !canSend,
            !isMicPressed
        else {
            return
        }

        withAnimation(
            .easeOut(
                duration:
                    0.12
            )
        ) {
            showMenu =
                false
        }

        isMicPressed =
            true

        cancelRecording =
            false
    }

    private func startInlineRecording() {
        guard
            isMicPressed,
            !canSend,
            !isInlineRecording,
            !audioRecorder
                .isRecording,
            !audioRecorder
                .isPreparing
        else {
            return
        }

        Task<Void, Never> {
            @MainActor in

            let started =
                await audioRecorder
                .startRecordingForHold()

            guard
                started
            else {
                return
            }

            guard
                isMicPressed
            else {
                audioRecorder
                    .cancel()
                return
            }

            isInlineRecording =
                true

            UIImpactFeedbackGenerator(
                style:
                    .medium
            )
            .impactOccurred()
        }
    }

    private func finishMicPress() {
        isMicPressed =
            false

        if
            audioRecorder
                .isPreparing,
            !isInlineRecording,
            !audioRecorder
                .isRecording
        {
            audioRecorder
                .cancel()

            resetInlineState()
            return
        }

        guard
            isInlineRecording ||
            audioRecorder
                .isRecording
        else {
            cancelRecording =
                false
            return
        }

        if cancelRecording {
            audioRecorder
                .cancel()

            UINotificationFeedbackGenerator()
                .notificationOccurred(
                    .warning
                )

            resetInlineState()
            return
        }

        if audioRecorder
            .isRecording
        {
            audioRecorder
                .stopRecording()
        }

        guard
            let recording =
                audioRecorder
                .recording
        else {
            audioRecorder
                .shutdown()

            resetInlineState()
            return
        }

        UINotificationFeedbackGenerator()
            .notificationOccurred(
                .success
            )

        onAudioRecorded(
            recording
        )

        audioRecorder
            .shutdown()

        resetInlineState()
    }

    private func resetInlineState() {
        isInlineRecording =
            false

        cancelRecording =
            false

        isMicPressed =
            false
    }

    // MARK: - Send

    private func sendMessage() {
        guard canSend else {
            return
        }

        withAnimation(
            .spring(
                response:
                    0.2,
                dampingFraction:
                    0.6
            )
        ) {
            isSending =
                true
        }

        onSend()

        sendTrigger.toggle()

        DispatchQueue.main
            .asyncAfter(
                deadline:
                    .now() +
                    0.18
            )
        {
            withAnimation(
                .spring(
                    response:
                        0.25,
                    dampingFraction:
                        0.75
                )
            ) {
                isSending =
                    false
            }
        }
    }
}

#Preview {
    ChatInputBar(
        text:
            .constant(
                ""
            ),
        sendTrigger:
            .constant(
                false
            ),
        onSend: {},
        onAttachment: {
            _ in
        }
    )
}
