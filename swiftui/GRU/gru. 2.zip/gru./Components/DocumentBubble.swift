//
//  DocumentBubble.swift
//  gru.
//
//  Created by Maria Morozova on 04.07.2026.
//


import SwiftUI

struct DocumentBubble: View {

    let attachment: Attachment

    var body: some View {

        HStack(spacing: 14) {

            Image(systemName: "doc.fill")
                .font(.title2)
                .foregroundStyle(GRUColors.accent)

            VStack(alignment: .leading, spacing: 4) {

                Text(attachment.fileName)
                    .font(.headline)
                    .lineLimit(1)

                Text(fileSize)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "arrow.down.circle")
                .font(.title3)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: 260)
        .background(GRUColors.card)
        .clipShape(
            RoundedRectangle(cornerRadius: 18)
        )
    }

    private var fileSize: String {

        ByteCountFormatter.string(
            fromByteCount: attachment.size,
            countStyle: .file
        )
    }
}

#Preview {

    DocumentBubble(
        attachment: Attachment(
            type: .document,
            fileName: "Contract.pdf",
            size: 1420000
        )
    )
}