
import SwiftUI
import UIKit

struct MessageBubble: View {

    let message: Message

    let isCurrentUser: Bool

    let onReply: (Message) -> Void

    let onDeleteLocal: (Message) -> Void

    let onDeleteForEveryone: (Message) -> Void

    let onSaveVideoNote: (Message) -> Void

    let onReaction: (
        ReactionType,
        Message
    ) -> Void

    var body: some View {

        HStack(
            alignment: .bottom
        ) {

            if isCurrentUser {

                Spacer(
                    minLength: 60
                )
            }

            VStack(
                alignment: .leading,
                spacing: 8
            ) {

                if let reply =
                    message.replyTo {

                    ReplyPreview(
                        message: reply
                    )
                }

                if let attachment =
                    message.attachment {

                    AttachmentContent(
                        attachment:
                            attachment
                    )
                }

                if !message.text.isEmpty {

                    BubbleText(
                        text:
                            message.text,
                        currentUser:
                            isCurrentUser
                    )
                }

                if let reaction =
                    message.reaction {

                    Text(
                        reaction.emoji
                    )
                    .font(.title3)
                    .padding(
                        .horizontal,
                        8
                    )
                    .padding(
                        .vertical,
                        4
                    )
                    .background(
                        GRUColors.card
                    )
                    .clipShape(
                        Capsule()
                    )
                }

                // MARK: Time + Status

                HStack(
                    spacing: 5
                ) {

                    Spacer()

                    Menu {
                        messageActions
                    } label: {
                        GRUNeonIcon(
                            systemName: "ellipsis",
                            size: 26,
                            iconSize: 11
                        )
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Действия с сообщением")

                    Text(
                        timeString
                    )
                    .font(.caption2)
                    .foregroundStyle(
                        .secondary
                    )

                    if isCurrentUser {

                        statusView
                    }
                }
            }

            if !isCurrentUser {

                Spacer(
                    minLength: 60
                )
            }
        }
        .padding(
            .horizontal
        )
        .contextMenu {
            messageActions
        }
        .gesture(

            DragGesture(
                minimumDistance: 30
            )
            .onEnded { value in

                if value.translation.width >
                    60 {

                    onReply(
                        message
                    )
                }
            }
        )
    }

    @ViewBuilder
    private var messageActions: some View {
        Button {
            onReply(message)
        } label: {
            Label("Ответить", systemImage: "arrowshape.turn.up.left")
        }

        Menu("Реакция") {
            ForEach(ReactionType.allCases) { reaction in
                Button(reaction.emoji) {
                    onReaction(reaction, message)
                }
            }
        }

        if !message.text.isEmpty {
            Button {
                UIPasteboard.general.string = message.text
            } label: {
                Label("Копировать", systemImage: "doc.on.doc")
            }
        }

        if message.attachment?.type == .videoNote {
            Button {
                onSaveVideoNote(message)
            } label: {
                Label("Сохранить кружок в профиль", systemImage: "bookmark.fill")
            }
        }

        Divider()

        Button(role: .destructive) {
            onDeleteLocal(message)
        } label: {
            Label("Удалить у меня", systemImage: "trash")
        }

        if isCurrentUser {
            Button(role: .destructive) {
                onDeleteForEveryone(message)
            } label: {
                Label("Удалить у всех", systemImage: "trash.slash")
            }
        }
    }

    // MARK: - Delivery Status

    @ViewBuilder
    private var statusView: some View {

        switch message.status {

        case .sending:

            Image(
                systemName: "clock"
            )
            .font(
                .system(
                    size: 10,
                    weight: .medium
                )
            )
            .foregroundStyle(
                .secondary
            )

        case .sent:

            Text("✓")
                .font(
                    .system(
                        size: 11,
                        weight: .semibold
                    )
                )
                .foregroundStyle(
                    .secondary
                )

        case .delivered:

            Text("✓✓")
                .font(
                    .system(
                        size: 11,
                        weight: .semibold
                    )
                )
                .tracking(-2)
                .foregroundStyle(
                    .secondary
                )

        case .read:

            Text("✓✓")
                .font(
                    .system(
                        size: 11,
                        weight: .bold
                    )
                )
                .tracking(-2)
                .foregroundStyle(
                    GRUColors.accent
                )

        case .failed:

            Image(
                systemName:
                    "exclamationmark.circle.fill"
            )
            .font(
                .system(
                    size: 11
                )
            )
            .foregroundStyle(
                .red
            )
        }
    }

    private var timeString: String {

        let formatter =
            DateFormatter()

        formatter.dateFormat =
            "HH:mm"

        return formatter.string(
            from: message.sentAt
        )
    }
}

// MARK: - Bubble Text

private struct BubbleText: View {

    let text: String

    let currentUser: Bool

    var body: some View {

        Text(text)
            .padding(
                .horizontal,
                14
            )
            .padding(
                .vertical,
                10
            )
            .background(

                currentUser
                    ? GRUColors.accent
                    : GRUColors.card
            )
            .foregroundStyle(

                currentUser
                    ? .white
                    : GRUColors.text
            )
            .clipShape(

                RoundedRectangle(
                    cornerRadius: 18
                )
            )
    }
}

// MARK: - Reply

private struct ReplyPreview: View {

    let message: Message

    var body: some View {

        VStack(
            alignment: .leading,
            spacing: 4
        ) {

            Text("Ответ")
                .font(
                    .caption2.bold()
                )
                .foregroundStyle(
                    GRUColors.accent
                )

            if let attachment = message.attachment {
                AttachmentContent(attachment: attachment)
            } else {

                Text(
                    message.text
                )
                .font(.caption)
                .lineLimit(1)
            }
        }
        .padding(8)
        .background(
            Color.gray.opacity(
                0.12
            )
        )
        .clipShape(
            RoundedRectangle(
                cornerRadius: 12
            )
        )
    }
}

// MARK: - Attachment

private struct AttachmentContent: View {

    let attachment: Attachment

    @ViewBuilder
    var body: some View {

        switch attachment.type {

        case .photo:

            ImageBubble(
                attachment:
                    attachment
            )

        case .video:

            VideoBubble(
                attachment:
                    attachment
            )

        case .videoNote:

            VideoNoteBubble(
                attachment:
                    attachment
            )

        case .document:

            DocumentBubble(
                attachment:
                    attachment
            )

        case .audio:

            AudioBubble(
                attachment:
                    attachment
            )
        }
    }
}
