import AVFoundation
import PhotosUI
import SwiftUI
import Combine

struct VideoNoteRecorderView: View {

    @Environment(\.dismiss)
    private var dismiss

    @StateObject
    private var recorder = VideoNoteRecorderModel()

    @State
    private var selectedLibraryVideo: PhotosPickerItem?

    let onFinished: (URL) -> Void

    var body: some View {
        ZStack {
            Color.black
                .ignoresSafeArea()

            VStack(spacing: 0) {
                header

                Spacer(minLength: 18)

                preview

                Spacer(minLength: 20)

                timer

                Spacer(minLength: 24)

                controls
                    .padding(.bottom, 28)
            }
        }
        .onAppear {
            recorder.onRecordingFinished = { url in
                onFinished(url)
                dismiss()
            }

            recorder.prepare()
        }
        .onDisappear {
            recorder.shutdown()
        }
        .onChange(of: selectedLibraryVideo) { _, item in
            guard let item else {
                return
            }

            selectedLibraryVideo = nil

            Task {
                do {
                    guard let picked =
                        try await item.loadTransferable(
                            type: PickedVideo.self
                        )
                    else {
                        return
                    }

                    await MainActor.run {
                        onFinished(picked.url)
                        dismiss()
                    }
                } catch {
                    print(
                        "❌ Cat video note gallery error:",
                        error
                    )
                }
            }
        }
    }

    private var header: some View {
        HStack {
            Button {
                recorder.cancelRecordingIfNeeded()
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(
                        .system(
                            size: 17,
                            weight: .bold
                        )
                    )
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(GRUColors.accent.opacity(0.13))
                    .clipShape(Circle())
                    .overlay { Circle().stroke(GRUColors.accent.opacity(0.42), lineWidth: 1) }
                    .shadow(color: GRUColors.accent.opacity(0.22), radius: 8)
            }

            Spacer()

            VStack(spacing: 2) {
                Text("gru кружок")
                    .font(
                        .system(
                            size: 17,
                            weight: .semibold,
                            design: .rounded
                        )
                    )
                    .foregroundStyle(.white)

                Text("до 60 секунд")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.55))
            }

            Spacer()

            Color.clear
                .frame(width: 42, height: 42)
        }
        .padding(.horizontal, 18)
        .padding(.top, 12)
    }

    private var preview: some View {
        ZStack {
            if recorder.isReady {
                VideoNoteCameraPreview(
                    session: recorder.session,
                    isMirrored: recorder.isFrontCamera
                )
                .frame(width: 292, height: 316)
                .clipShape(CatVideoNoteShape())
            } else {
                CatVideoNoteShape()
                    .fill(.white.opacity(0.08))
                    .frame(width: 292, height: 316)
                    .overlay {
                        if recorder.isPreparing {
                            ProgressView()
                                .tint(.white)
                        } else {
                            VStack(spacing: 12) {
                                Image(systemName: "video.slash.fill")
                                    .font(.system(size: 34))

                                Text(
                                    recorder.errorText ??
                                        "Камера недоступна"
                                )
                                .font(.subheadline)
                                .multilineTextAlignment(.center)
                            }
                            .foregroundStyle(.white.opacity(0.72))
                            .padding(24)
                        }
                    }
            }

            CatVideoNoteShape()
                .stroke(
                    recorder.isRecording
                        ? .white.opacity(0.95)
                        : .white.opacity(0.16),
                    lineWidth:
                        recorder.isRecording
                            ? 3
                            : 1
                )
                .frame(width: 292, height: 316)
                .animation(
                    .easeInOut(duration: 0.18),
                    value: recorder.isRecording
                )
        }
        .shadow(
            color: .black.opacity(0.28),
            radius: 24,
            y: 12
        )
    }

    private var timer: some View {
        HStack(spacing: 7) {
            Circle()
                .fill(
                    recorder.isRecording
                        ? .red
                        : .white.opacity(0.35)
                )
                .frame(width: 7, height: 7)

            Text(recorder.elapsedText)
                .font(
                    .system(
                        size: 14,
                        weight: .semibold,
                        design: .monospaced
                    )
                )
                .foregroundStyle(.white.opacity(0.84))
        }
    }

    private var controls: some View {
        HStack(spacing: 42) {
            PhotosPicker(
                selection: $selectedLibraryVideo,
                matching: .videos
            ) {
                Image(systemName: "photo.on.rectangle")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 48, height: 48)
                    .background(GRUColors.accent.opacity(0.13))
                    .clipShape(Circle())
                    .overlay { Circle().stroke(GRUColors.accent.opacity(0.42), lineWidth: 1) }
                    .shadow(color: GRUColors.accent.opacity(0.22), radius: 8)
            }
            .disabled(recorder.isRecording)
            .opacity(recorder.isRecording ? 0.35 : 1)

            Button {
                recorder.toggleRecording()
            } label: {
                ZStack {
                    Circle()
                        .fill(.black.opacity(0.62))
                        .frame(width: 82, height: 82)

                    Circle()
                        .stroke(
                            LinearGradient(
                                colors: [
                                    GRUColors.accent,
                                    .white.opacity(0.86),
                                    Color.cyan.opacity(0.78),
                                    GRUColors.accent
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: recorder.isRecording ? 4 : 3
                        )
                        .frame(width: 78, height: 78)
                        .shadow(color: GRUColors.accent.opacity(0.70), radius: 16)
                        .shadow(color: Color.cyan.opacity(0.28), radius: 26)

                    if recorder.isRecording {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(Color.red)
                            .frame(width: 30, height: 30)
                    } else {
                        Circle()
                            .fill(GRUColors.accent.opacity(0.13))
                            .frame(width: 62, height: 62)

                        Image(systemName: "pawprint.fill")
                            .font(.system(size: 30, weight: .bold))
                            .foregroundStyle(.white)
                            .shadow(color: GRUColors.accent.opacity(0.95), radius: 8)
                    }
                }
                .animation(.spring(response: 0.24), value: recorder.isRecording)
            }
            .disabled(!recorder.isReady)
            .opacity(recorder.isReady ? 1 : 0.35)

            Button {
                recorder.flipCamera()
            } label: {
                Image(systemName: "arrow.triangle.2.circlepath.camera.fill")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 48, height: 48)
                    .background(GRUColors.accent.opacity(0.13))
                    .clipShape(Circle())
                    .overlay { Circle().stroke(GRUColors.accent.opacity(0.42), lineWidth: 1) }
                    .shadow(color: GRUColors.accent.opacity(0.22), radius: 8)
            }
            .disabled(
                !recorder.isReady ||
                    recorder.isRecording
            )
            .opacity(
                recorder.isReady && !recorder.isRecording
                    ? 1
                    : 0.35
            )
        }
    }
}

final class VideoNoteRecorderModel:
    NSObject,
    ObservableObject,
    AVCaptureFileOutputRecordingDelegate
{
    let session = AVCaptureSession()

    @Published private(set) var isPreparing = false
    @Published private(set) var isReady = false
    @Published private(set) var isRecording = false
    @Published private(set) var isFrontCamera = true
    @Published private(set) var elapsed: TimeInterval = 0
    @Published private(set) var errorText: String?

    var onRecordingFinished: ((URL) -> Void)?

    private let movieOutput = AVCaptureMovieFileOutput()

    /// All AVCaptureSession mutations live on one serial queue.
    /// This prevents startRunning/stopRunning from racing with
    /// beginConfiguration/commitConfiguration.
    private let sessionQueue = DispatchQueue(
        label: "gru.video-note.capture-session",
        qos: .userInitiated
    )

    private var currentVideoInput: AVCaptureDeviceInput?
    private var timer: Timer?
    private var recordingURL: URL?
    private var didCancelRecording = false
    private var isSessionConfigured = false

    var elapsedText: String {
        let value = min(Int(elapsed), 60)
        return String(
            format: "0:%02d / 1:00",
            value
        )
    }

    // MARK: - Prepare

    func prepare() {
        guard !isPreparing, !isReady else {
            return
        }

        isPreparing = true
        errorText = nil

        Task {
            let videoAllowed =
                await Self.requestAccess(
                    for: .video
                )

            let audioAllowed =
                await Self.requestAccess(
                    for: .audio
                )

            await MainActor.run {
                guard videoAllowed else {
                    self.isPreparing = false
                    self.errorText =
                        "Разреши доступ к камере в Настройках"
                    return
                }

                guard audioAllowed else {
                    self.isPreparing = false
                    self.errorText =
                        "Разреши доступ к микрофону в Настройках"
                    return
                }

                self.configureAndStartSession()
            }
        }
    }

    private static func requestAccess(
        for mediaType: AVMediaType
    ) async -> Bool {
        switch AVCaptureDevice.authorizationStatus(
            for: mediaType
        ) {
        case .authorized:
            return true

        case .notDetermined:
            return await AVCaptureDevice.requestAccess(
                for: mediaType
            )

        default:
            return false
        }
    }

    // MARK: - Session

    private func configureAndStartSession() {
        sessionQueue.async { [weak self] in
            guard let self else {
                return
            }

            do {
                if !self.isSessionConfigured {
                    try self.configureSessionGraph()
                    self.isSessionConfigured = true
                }

                // IMPORTANT:
                // startRunning is intentionally AFTER commitConfiguration,
                // and executes on the same serial sessionQueue.
                if !self.session.isRunning {
                    self.session.startRunning()
                }

                let running = self.session.isRunning
                let isFront =
                    self.currentVideoInput?.device.position == .front

                DispatchQueue.main.async {
                    self.isPreparing = false
                    self.isReady = running
                    self.isFrontCamera = isFront
                    self.errorText =
                        running
                            ? nil
                            : "Не удалось запустить камеру"
                }
            } catch {
                DispatchQueue.main.async {
                    self.isPreparing = false
                    self.isReady = false
                    self.errorText = error.localizedDescription
                }
            }
        }
    }

    /// Configures inputs/output only.
    /// This method ALWAYS commits before it returns.
    private func configureSessionGraph() throws {
        session.beginConfiguration()

        do {
            session.sessionPreset = .hd1280x720

            // Clean up partially configured state if prepare() is retried.
            for input in session.inputs {
                session.removeInput(input)
            }

            if session.outputs.contains(
                where: { $0 === movieOutput }
            ) {
                session.removeOutput(movieOutput)
            }

            let videoDevice =
                try preferredCamera(
                    position: .front
                )

            let videoInput =
                try AVCaptureDeviceInput(
                    device: videoDevice
                )

            guard session.canAddInput(videoInput) else {
                throw RecorderError.cannotAddVideoInput
            }

            session.addInput(videoInput)
            currentVideoInput = videoInput

            if let audioDevice =
                AVCaptureDevice.default(
                    for: .audio
                ) {
                let audioInput =
                    try AVCaptureDeviceInput(
                        device: audioDevice
                    )

                if session.canAddInput(audioInput) {
                    session.addInput(audioInput)
                }
            }

            guard session.canAddOutput(movieOutput) else {
                throw RecorderError.cannotAddMovieOutput
            }

            session.addOutput(movieOutput)

            movieOutput.maxRecordedDuration =
                CMTime(
                    seconds: 60,
                    preferredTimescale: 600
                )

            if let connection =
                movieOutput.connection(
                    with: .video
                )
            {
                configurePortraitRotation(
                    on: connection
                )
                configureMirroring(
                    on: connection,
                    mirrored: videoDevice.position == .front
                )
            }

            // Configuration is fully finished here.
            session.commitConfiguration()

        } catch {
            // AVCaptureSession MUST always leave configuration mode,
            // even when an input/output fails to configure.
            session.commitConfiguration()
            throw error
        }
    }

    // MARK: - Rotation

    private func configurePortraitRotation(
        on connection: AVCaptureConnection
    ) {
        if #available(iOS 17.0, *) {
            if connection.isVideoRotationAngleSupported(90) {
                connection.videoRotationAngle = 90
            }
        } else if connection.isVideoOrientationSupported {
            connection.videoOrientation = .portrait
        }
    }

    private func configureMirroring(
        on connection: AVCaptureConnection,
        mirrored: Bool
    ) {
        guard connection.isVideoMirroringSupported else {
            return
        }

        connection.automaticallyAdjustsVideoMirroring = false
        connection.isVideoMirrored = mirrored
    }

    // MARK: - Recording

    func toggleRecording() {
        if isRecording {
            stopRecording()
        } else {
            startRecording()
        }
    }

    private func startRecording() {
        guard isReady else {
            return
        }

        let url =
            FileManager.default
                .temporaryDirectory
                .appendingPathComponent(
                    "gru-cat-note-\(UUID().uuidString)"
                )
                .appendingPathExtension("mov")

        try? FileManager.default.removeItem(
            at: url
        )

        recordingURL = url
        didCancelRecording = false
        elapsed = 0

        sessionQueue.async { [weak self] in
            guard let self else {
                return
            }

            guard
                self.session.isRunning,
                !self.movieOutput.isRecording
            else {
                return
            }

            if let connection =
                self.movieOutput.connection(
                    with: .video
                )
            {
                self.configurePortraitRotation(
                    on: connection
                )
                self.configureMirroring(
                    on: connection,
                    mirrored:
                        self.currentVideoInput?.device.position == .front
                )
            }

            self.movieOutput.startRecording(
                to: url,
                recordingDelegate: self
            )

            DispatchQueue.main.async {
                self.isRecording = true
                self.startTimer()
            }
        }
    }

    private func stopRecording() {
        sessionQueue.async { [weak self] in
            guard let self else {
                return
            }

            guard self.movieOutput.isRecording else {
                return
            }

            self.movieOutput.stopRecording()
        }
    }

    func cancelRecordingIfNeeded() {
        sessionQueue.async { [weak self] in
            guard let self else {
                return
            }

            if self.movieOutput.isRecording {
                self.didCancelRecording = true
                self.movieOutput.stopRecording()
            }
        }
    }

    // MARK: - Flip Camera

    func flipCamera() {
        guard isReady, !isRecording else {
            return
        }

        sessionQueue.async { [weak self] in
            guard
                let self,
                !self.movieOutput.isRecording,
                let oldInput = self.currentVideoInput
            else {
                return
            }

            let newPosition: AVCaptureDevice.Position =
                oldInput.device.position == .front
                    ? .back
                    : .front

            do {
                let device =
                    try self.preferredCamera(
                        position: newPosition
                    )

                let newInput =
                    try AVCaptureDeviceInput(
                        device: device
                    )

                self.session.beginConfiguration()
                self.session.removeInput(oldInput)

                if self.session.canAddInput(newInput) {
                    self.session.addInput(newInput)
                    self.currentVideoInput = newInput
                } else {
                    self.session.addInput(oldInput)
                }

                self.session.commitConfiguration()

                let isFront =
                    self.currentVideoInput?.device.position == .front

                if let connection =
                    self.movieOutput.connection(
                        with: .video
                    )
                {
                    self.configurePortraitRotation(
                        on: connection
                    )
                    self.configureMirroring(
                        on: connection,
                        mirrored: isFront
                    )
                }

                DispatchQueue.main.async {
                    self.isFrontCamera = isFront
                }

            } catch {
                DispatchQueue.main.async {
                    self.errorText = error.localizedDescription
                }
            }
        }
    }

    private func preferredCamera(
        position: AVCaptureDevice.Position
    ) throws -> AVCaptureDevice {
        let discovery =
            AVCaptureDevice.DiscoverySession(
                deviceTypes: [
                    .builtInWideAngleCamera,
                    .builtInTrueDepthCamera
                ],
                mediaType: .video,
                position: position
            )

        if let device = discovery.devices.first {
            return device
        }

        throw RecorderError.cameraUnavailable
    }

    // MARK: - Timer

    private func startTimer() {
        timer?.invalidate()

        timer =
            Timer.scheduledTimer(
                withTimeInterval: 0.2,
                repeats: true
            ) { [weak self] _ in
                guard let self else {
                    return
                }

                let seconds =
                    CMTimeGetSeconds(
                        self.movieOutput.recordedDuration
                    )

                if seconds.isFinite {
                    self.elapsed = seconds
                }
            }
    }

    private func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    // MARK: - Shutdown

    func shutdown() {
        stopTimer()

        // Serializing shutdown with configuration is important.
        // If configureSessionGraph() is still running, this block waits
        // until commitConfiguration() has completed.
        sessionQueue.async { [weak self] in
            guard let self else {
                return
            }

            if self.movieOutput.isRecording {
                self.didCancelRecording = true
                self.movieOutput.stopRecording()
            }

            if self.session.isRunning {
                self.session.stopRunning()
            }

            DispatchQueue.main.async {
                self.isReady = false
                self.isPreparing = false
            }
        }
    }

    // MARK: - AVCaptureFileOutputRecordingDelegate

    nonisolated func fileOutput(
        _ output: AVCaptureFileOutput,
        didFinishRecordingTo outputFileURL: URL,
        from connections: [AVCaptureConnection],
        error: Error?
    ) {
        Task { @MainActor in
            self.stopTimer()
            self.isRecording = false

            if self.didCancelRecording {
                try? FileManager.default.removeItem(
                    at: outputFileURL
                )
                self.didCancelRecording = false
                return
            }

            if let error {
                let nsError = error as NSError
                let finishedSuccessfully =
                    nsError.userInfo[
                        AVErrorRecordingSuccessfullyFinishedKey
                    ] as? Bool ?? false

                if !finishedSuccessfully {
                    self.errorText =
                        error.localizedDescription
                    return
                }
            }

            guard FileManager.default.fileExists(
                atPath: outputFileURL.path
            ) else {
                self.errorText =
                    "Видео не сохранилось"
                return
            }

            self.onRecordingFinished?(
                outputFileURL
            )
        }
    }
}

private enum RecorderError: LocalizedError {
    case cameraUnavailable
    case cannotAddVideoInput
    case cannotAddMovieOutput

    var errorDescription: String? {
        switch self {
        case .cameraUnavailable:
            return "Камера недоступна"
        case .cannotAddVideoInput:
            return "Не удалось подключить камеру"
        case .cannotAddMovieOutput:
            return "Не удалось запустить запись видео"
        }
    }
}

private struct VideoNoteCameraPreview: UIViewRepresentable {

    let session: AVCaptureSession
    let isMirrored: Bool

    func makeUIView(
        context: Context
    ) -> VideoNoteCameraPreviewView {
        let view = VideoNoteCameraPreviewView()
        view.previewLayer.session = session
        view.previewLayer.videoGravity = .resizeAspectFill
        applyMirroring(
            to: view.previewLayer
        )
        return view
    }

    func updateUIView(
        _ uiView: VideoNoteCameraPreviewView,
        context: Context
    ) {
        uiView.previewLayer.session = session
        applyMirroring(
            to: uiView.previewLayer
        )
    }

    private func applyMirroring(
        to previewLayer: AVCaptureVideoPreviewLayer
    ) {
        guard let connection =
            previewLayer.connection
        else {
            return
        }

        guard connection.isVideoMirroringSupported else {
            return
        }

        connection.automaticallyAdjustsVideoMirroring = false
        connection.isVideoMirrored = isMirrored
    }
}

private final class VideoNoteCameraPreviewView: UIView {

    override class var layerClass: AnyClass {
        AVCaptureVideoPreviewLayer.self
    }

    var previewLayer: AVCaptureVideoPreviewLayer {
        layer as! AVCaptureVideoPreviewLayer
    }
}
