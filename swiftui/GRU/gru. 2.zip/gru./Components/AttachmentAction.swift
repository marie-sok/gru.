import Foundation

enum AttachmentAction {
    case photo
    case video
    case document
    case voice
    case videoNote
    case contact
}
