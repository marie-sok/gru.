//
//  VideoBubble.swift
//  gru.
//
//  Created by Maria Morozova on 04.07.2026.
//


import SwiftUI
import AVKit

struct VideoBubble: View {

    let attachment: Attachment

    @State private var player: AVPlayer?

    var body: some View {

        Group {

            if let path = attachment.localPath {

                VideoPlayer(
                    player: player
                )
                .frame(width: 240, height: 220)
                .clipShape(
                    RoundedRectangle(cornerRadius: 20)
                )
                .onAppear {

                    player = AVPlayer(
                        url: URL(fileURLWithPath: path)
                    )
                }

            } else {

                RoundedRectangle(cornerRadius: 20)
                    .fill(.gray.opacity(0.15))
                    .frame(width: 240, height: 220)
                    .overlay {

                        VStack(spacing: 10) {

                            Image(systemName: "video.fill")
                                .font(.system(size: 34))

                            Text("Видео")
                        }
                    }
            }
        }
    }
}

#Preview {

    VideoBubble(
        attachment: Attachment(
            type: .video,
            fileName: "movie.mov"
        )
    )
}